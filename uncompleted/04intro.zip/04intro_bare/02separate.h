/* Copyright 2018 */

#ifndef NOTES_04INTRO_02SEPARATE_H_
#define NOTES_04INTRO_02SEPARATE_H_

#include <iostream>
using std::cout;
using std::endl;

// Write a void function which displays Hello, World named HelloWorld01

// Write a void function which displays Hello, World named HelloWorld02

#endif
