/* Copyright 2018 */
#include "03call_by.h"

// Write function body named SwapByVal which attempts to swap ints a and b
void SwapByVal(int a, int b) {
}

// Write function body SwapByRef which attempts to swap ints a and b
void SwapByRef(int& a, int& b) {
}

int main(int argc, char* argv[]) {
  // seed random number generate with current time
  srand(time(nullptr));

  // create two ints and randomly assign vals from [1, 100]
  int f = rand() % 100 + 1,
      s = rand() % 100 + 1;

  // display f and s's values

  // call SwapByVal and show it does not. 

  // call SwapByRef and show it does.

  return 0;
}

