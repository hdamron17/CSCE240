/* Copyright 2018 */
#include <iostream>
using std::cout;
using std::endl;

//  Write a void function which displays Hello, World named HelloWorld01

int main(int argc, char* argv[]) {
  // call HelloWorld01

  // call HelloWorld02

  return 0;
}

//  Write a void function which displays Hello, World named HelloWorld02
