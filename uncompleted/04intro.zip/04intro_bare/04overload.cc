/* Copyright 2018 */
#include "04overload.h"


// A function body with two int variables, named Min

// A function body with two double variables, named Min

// A function body with two char variables named Min

int main(int argc, char* argv[]) {
  // seed random number generate with current time
  srand(time(nullptr));

  // create two elem int array and randomly assign integer vals from [1, 100]

  // create two elem double array and randomly assign FP vals from [1.0, 100.0]

  // create two elem char array and randomly assign integer vals from [A, Z]

  // display the min of each set

  // display min of int and double

  return 0;
}

