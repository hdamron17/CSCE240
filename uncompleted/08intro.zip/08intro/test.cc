/* Copyright 2018 */
#include "test.h"

int main(int argc, char* argv[]) {
  cout << "Testing Rational Class" << endl;

  int passed = 0, failed = 0;
  if (TestRationalCreation("  ")) {
    ++passed;
  }
  else {
    ++failed;
  }

  if (TestRationalAddOp("  ")) {
    ++passed;
  }
  else {
    ++failed;
  }

  cout << passed << " of " << (passed + failed) << " passed" << endl;

  return 0;
}

bool TestRationalCreation(const String& align) {
  cout << "\tTestRationalCreation" << endl;

  Rational a, b(2, 5), c(1, 0);
  bool valid = true;

  if (a.num() != 0) {
    valid = false;
    cout << align << " Expected: 0, Actual: " << a.num() << endl;
  }

  if (a.den() != 1) {
    valid = false;
    cout << align << " Expected: 1, Actual: " << a.den() << endl;
  }

  if (b.num() != 2) {
    valid = false;
    cout << align << " Expected: 2, Actual: " << b.num() << endl;
  }

  if (b.den() != 5) {
    valid = false;
    cout << align << " Expected: 5, Actual: " << b.den() << endl;
  }

  if (c.num() != 1) {
    valid = false;
    cout << align << " Expected: 1, Actual: " << c.num() << endl;
  }

  if (c.den() != 0) {
    valid = false;
    cout << align << " Expected: 0, Actual: " << c.den() << endl;
  }

  if (!c.is_nan()) {
    valid = false;
    cout << align << " Expected: true, Actual: " <<
      (c.is_nan() ? "true" : "false") << endl;
  }

  return valid;
}

bool TestRationalAddOp(const String& align) {
  cout << "\tTestRationalAddOp" << endl;
  Rational a(1, 3), b(3, 9), c, d(17845, 0);
  c = a.AddOp(b);

  bool valid = true;
  if (c.num() != 2) {
    valid = false;
    cout << align << " Expected: 2, Actual: " << c.num() << endl;
  }

  if (c.den() != 3) {
    valid = false;
    cout << align << " Expected: 3, Actual: " << c.den() << endl;
  }

  c = a.AddOp(d);
  if (!c.is_nan()) {
    cout << align << " Expected: true, Actual: " <<
      (c.is_nan() ? "true" : "false") << endl;
  }
  return valid;
}

