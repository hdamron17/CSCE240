#include "rational.h"

Rational::Rational(int num, int den) : num_(num), den_(den), nan_(0 == den) {};

const Rational Rational::ToRational(double val) {
  int num = pow(10, conversion_precision_ - 1);

  Rational r(val*num, num);

  return r.Simplify();
}

/* THERE IS A LOGIC ERROR IN THIS METHOD. CAN YOU FIND IT? */
const Rational Rational::AddOp(const Rational& rhs) const {
  if (nan_)
    return Rational(0, 0);

  int den = den_ * rhs.den_;
  int num_lhs = num_ * rhs.den_;
  int num_rhs = rhs.num_ * den_;

  return Rational(num_lhs + num_rhs, den).Simplify();
}

const Rational Rational::Simplify() const {
  int gcd = CalcGCD(num_, den_);

  return Rational(num_ / gcd, den_ / gcd);
}

int Rational::CalcGCD(int a, int b) const {
  int gcd = 1;

  for (int i = a < b ? a : b; i > 1; --i) {
    if (0 == a%i && 0 == b%i) {
      gcd = i;
	  break;
	}
  }

  return gcd;
}
