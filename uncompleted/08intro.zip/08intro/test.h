/* Copyright 2018 */

#ifndef LECT_07INTRO_TEST_H_  // NOLINT
#define LECT_07INTRO_TEST_H_  // NOLINT

#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <string>
typedef std::string String;

#include "rational.h"

bool TestRationalCreation(const String& align);
bool TestRationalAddOp(const String& align);

#endif  // NOLINT
