#include "pointers.h"

int main(int argc, char* argv[]) {
  int a=3, b=4;

  cout << "a: " << a << ", b: " << b << endl;
  Swap(&a, &b);
  cout << "a: " << a << ", b: " << b << endl;

  return 0;
}
