/* Copyright 2018 */
#ifndef _LECT_08INTRO_POINTERS_H_  // NOLINT
#define _LECT_08INTRO_POINTERS_H_  // NOLINT

#include <iostream>
using std::cout;
using std::endl;

void Swap(int* a, int* b);
void ConstSwap(const int* a, const int* b);

#endif  // NOLINT
