/* Copyright 2018 */

#ifndef _LECT_07INTRO_RATIONAL_H_
#define _LECT_07INTRO_RATIONAL_H_

#include <cctype>
using std::isdigit;
#include <cmath>
// using abs
// using pow
#include <cstdlib>
// using atoi
#include <iostream>
using std::istream;
using std::ostream;
using std::ws;
#include <sstream>
#include <string>
#include <regex>


typedef std::stringstream StrStream;
typedef std::string String;

/* Rational class definition */
class Rational {
public:
  Rational(int num = 0, int den = 1);

  // create a static method to convert floating point to Rational instance
  static const Rational ToRational(double val);

  // create arithmetic ops for Rational instances and ints
  const Rational AddOp(const Rational& rhs) const;
  const Rational MulOp(const Rational& rhs) const;

  // create overloads for arithmetic ops
  const Rational operator+(const Rational& rhs) const;
  const Rational operator*(const Rational& rhs) const;

  // create ToString and ToFloat methods
  const String ToString() const;
  void operator<<(const Rational& lhs);  // we will fix these
  void operator>>(Rational& lhs);  // we will fix these

  double ToFloat() const;

  // create getters for members
  inline int num() const { return num_; };
  inline int den() const { return den_; };
  inline bool is_nan() const { return nan_; };

  // create method which creates, simplifies, and returns a new instance
  const Rational Simplify() const;
private:
  static const int conversion_precision_ = 6;  // used for double to rational

  int CalcGCD(int a, int b) const; // returns GCD of a and b

  int num_;
  int den_;
  bool nan_;
};

#endif
