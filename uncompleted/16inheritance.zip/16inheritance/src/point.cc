#include "../include/point.h"

namespace csce240 {

namespace two_dim {

void Point::AddOffset(const Vector* offset) {
  const Vector *vector = dynamic_cast<const Vector *>(offset);
  assert(vector);

  x_ += vector->x();
  y_ += vector->y();
}

void Point::GetOffset(const Point* end, Vector* offset) const {
  const Point *point = dynamic_cast<const Point *>(end);
  assert(point);
  Vector *vector = dynamic_cast<Vector *>(offset);
  assert(vector);

  vector->x(point->x_ - x_);
  vector->y(point->y_ - y_);
}

bool Point::operator==(const Point& rhs) const {
  return floating_point::equals(x_, rhs.x_)
      && floating_point::equals(y_, rhs.y_);
}

bool Point::operator!=(const Point& rhs) const {
  return !floating_point::equals(x_, rhs.x_)
      || !floating_point::equals(y_, rhs.y_);
}

const std::string Point::ToString() const {
  return "(" + std::to_string(x_) + ", " + std::to_string(y_) + ")";
}

std::ostream& operator<<(std::ostream& lhs, const Point& rhs) {
  lhs << "(" << rhs.x_ << ", " << rhs.y_ << ")";
  return lhs;
}

}  // namespace two_dim

namespace three_dim {

void Point::AddOffset(const Vector* offset) {
  const Vector *vector = dynamic_cast<const Vector *>(offset);
  assert(vector);

  x_ += vector->x();
  y_ += vector->y();
  z_ += vector->z();
}

void Point::GetOffset(const Point* end, Vector* offset) const {
  const Point *point = dynamic_cast<const Point *>(end);
  assert(point);
  Vector *vector = dynamic_cast<Vector *>(offset);
  assert(vector);

  vector->x(point->x_ - x_);
  vector->y(point->y_ - y_);
  vector->z(point->z_ - z_);
}

bool Point::operator==(const Point& rhs) const {
  return floating_point::equals(x_, rhs.x_)
      && floating_point::equals(y_, rhs.y_)
      && floating_point::equals(z_, rhs.z_);
}

bool Point::operator!=(const Point& rhs) const {
  return !floating_point::equals(x_, rhs.x_)
      || !floating_point::equals(y_, rhs.y_)
      || !floating_point::equals(z_, rhs.z_);
}

const std::string Point::ToString() const {
  return "(" + std::to_string(x_) + ", " + std::to_string(y_)
      + std::to_string(z_) + ")";
}

std::ostream& operator<<(std::ostream& lhs, const Point& rhs) {
  lhs << "(" << rhs.x_ << ", " << rhs.y_ << ", " << rhs.z_ << ")";
  return lhs;
}

}  // namespace three_dim

}  // namespace csce240
