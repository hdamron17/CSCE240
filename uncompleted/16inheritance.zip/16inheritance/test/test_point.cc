/* Copyright 2018 */

#include <iostream>

#include "../include/point.h"
#include "../include/vector.h"

bool TestCreateTwoDimPoint() {
  csce240::two_dim::Point p(1.0, 0.5);

  if (1.0 != p.x() || 0.5 != p.y()) {
    std::cout << " TestCreateTwoDimPoint FAILED ";
    std::cout << "Expected: (1.0, 0.5), Actual: (";
    std::cout << p.x() << ", " << p.y() << ")" << std::endl;
    return false;
  }

  return true;
}

bool TestAddTwoDimVectorToPoint() {
  csce240::two_dim::Point *p = new csce240::two_dim::Point(1.0, 0.5);
  csce240::two_dim::Vector v(1.0, 1.5);

  p->AddOffset(&v);

  if (2.0 != p->x() || 2.0 != p->y()) {
    std::cout << " TestAddTwoDimVectorToPoint FAILED ";
    std::cout << "Expected: (1.0, 0.5), Actual: " << p << std::endl;
    return false;
  }

  return true;
}

bool TestSubTwoDimPointFromPoint() {
  csce240::two_dim::Point p(1.0, 0.5);
  csce240::two_dim::Point q(1.0, 1.5);

  csce240::two_dim::Vector v;
  p.GetOffset(&q, &v);

  if (0.0 != v.x() || 1.0 != v.y()) {
    std::cout << " TestSubTwoDimPointFromPoint FAILED ";
    std::cout << "Expected: (0.0, 1.0), Actual: " << v << std::endl;
    return false;
  }

  return true;
}

bool TestCompareTwoDimPointToPoint() {
  csce240::two_dim::Point p1(1.0, 1.5);
  csce240::two_dim::Point p2(1.0, 1.5);
  csce240::two_dim::Point p3(0.99, 1.499);

  if (p1 != p2) {
    std::cout << " TestCompareTwoDimPointToPoint FAILED ";
    std::cout << "Expected: " << p1 << " == " << p2 << " ";
    std::cout << "Actual: " << p1 << " != " << p2 << std::endl;
    return false;
  }

  if (p2 == p3) {
    std::cout << " TestTwoDimComparePointToPoint FAILED ";
    std::cout << "Expected: " << p2 << " != " << p3 << " ";
    std::cout << "Actual: " << p2 << " == " << p3 << std::endl;
    return false;
  }

  return true;
}

bool TestCreateThreeDimPoint() {
  csce240::three_dim::Point p(1.0, 0.5, 0.22);

  if (1.0 != p.x() || 0.5 != p.y() || 0.22 != p.z()) {
    std::cout << " TestCreateThreeDimPoint FAILED ";
    std::cout << "Expected: (1.0, 0.5), Actual: (";
    std::cout << p.x() << ", " << p.y() << ", " << p.z() << ")" << std::endl;
    return false;
  }

  return true;
}

bool TestAddThreeDimVectorToPoint() {
  csce240::three_dim::Point p(1.0, 0.5, 1.7);
  csce240::three_dim::Vector v(1.0, 1.5, 0.3);

  p.AddOffset(&v);

  if (2.0 != p.x() || 2.0 != p.y() || 2.0 != p.z()) {
    std::cout << " TestAddThreeDimVectorToPoint FAILED ";
    std::cout << "Expected: (1.0, 0.5), Actual: " << p << std::endl;
    return false;
  }

  return true;
}

bool TestSubThreeDimPointFromPoint() {
  csce240::three_dim::Point p(1.0, 0.5, -1.0);
  csce240::three_dim::Point q(1.0, 1.5, 1.0);

  csce240::three_dim::Vector v;
  p.GetOffset(&q, &v);

  if (0.0 != v.x() || 1.0 != v.y() || 2.0 != v.z()) {
    std::cout << " TestSubThreeDimPointFromPoint FAILED ";
    std::cout << "Expected: (0.0, 1.0, 2.0), Actual: " << v << std::endl;
    return false;
  }

  return true;
}

bool TestCompareThreeDimPointToPoint() {
  csce240::three_dim::Point p1(1.0, 1.5, 1.7);
  csce240::three_dim::Point p2(1.0, 1.5, 1.7);
  csce240::three_dim::Point p3(0.99, 1.499, 1.700001);

  if (p1 != p2) {
    std::cout << " TestCompareThreeDimPointToPoint FAILED ";
    std::cout << "Expected: " << p1 << " == " << p2 << " ";
    std::cout << "Actual: " << p1 << " != " << p2 << std::endl;
    return false;
  }

  if (p2 == p3) {
    std::cout << " TestThreeDimComparePointToPoint FAILED ";
    std::cout << "Expected: " << p2 << " != " << p3 << " ";
    std::cout << "Actual: " << p2 << " == " << p3 << std::endl;
    return false;
  }

  return true;
}

int main(int argc, char* argv[]) {
  std::cout << "TESTING csce240::two_dim::Point CLASS" << std::endl;
  if (TestCreateTwoDimPoint())
    std::cout << " TestCreateTwoDimPoint PASSED" << std::endl;
  if (TestAddTwoDimVectorToPoint())
    std::cout << " TestAddTwoDimVectorToPoint PASSED" << std::endl;
  if (TestSubTwoDimPointFromPoint())
    std::cout << " TestSubTwoDimPointFromPoint PASSED" << std::endl;
  if (TestCompareTwoDimPointToPoint())
    std::cout << " TestCompareTwoDimPointToPoint PASSED" << std::endl;

  std::cout << "TESTING csce240::three_dim::Point CLASS" << std::endl;
  if (TestCreateThreeDimPoint())
    std::cout << " TestCreateThreeDimPoint PASSED" << std::endl;
  if (TestAddThreeDimVectorToPoint())
    std::cout << " TestAddThreeDimVectorToPoint PASSED" << std::endl;
  if (TestSubThreeDimPointFromPoint())
    std::cout << " TestSubThreeDimPointFromPoint PASSED" << std::endl;
  if (TestCompareThreeDimPointToPoint())
    std::cout << " TestCompareThreeDimPointToPoint PASSED" << std::endl;

  return 0;
}
