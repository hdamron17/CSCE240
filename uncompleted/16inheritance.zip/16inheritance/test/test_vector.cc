/* Copyright 2018 */

#include <cmath>
// using sqrt
#include <iostream>

#include "../include/point.h"
#include "../include/vector.h"

bool TestCreateTwoDimVector() {
  csce240::two_dim::Vector v(1.0, 0.5);

  if (1.0 != v.x() || 0.5 != v.y()) {
    std::cout << " TestCreateTwoDimVector FAILED ";
    std::cout << "Expected (1.0, 0.5), Actual(";
    std::cout << v.x() << ", " << v.y() << ")" << std::endl;
    return false;
  }

  return true;
}

bool TestGetLengthOfTwoDimVector() {
  csce240::two_dim::Vector v(3.0, 4.0);

  if (5.0 != v.GetLength()) {
    std::cout << " TestGetLengthOfTwoDimVector FAILED ";
    std::cout << "Expected 5.0 " << "Actual " << v.GetLength() << std::endl;
    return false;
  }

  return true;
}


bool TestCreateThreeDimVector() {
  csce240::three_dim::Vector v(1.0, 0.5, 0.22);

  if (1.0 != v.x() || 0.5 != v.y() || 0.22 != v.z()) {
    std::cout << " TestCreateThreeDimVector FAILED ";
    std::cout << "Expected: (1.0, 0.5, 0.22) Actual: (";
    std::cout << v.x() << ", " << v.y() << ", " << v.z() << ")" << std::endl;
    return false;
  }

  return true;
}

bool TestGetLengthOfThreeDimVector() {
  csce240::three_dim::Vector v(3.0, 4.0, 12.0);

  if (13.0 != v.GetLength()) {
    std::cout << " TestAddThreeDimVectorToVector FAILED ";
    std::cout << "Expected: 13, Actual: " << v.GetLength() << std::endl;
    return false;
  }

  return true;
}


int main(int argc, char* argv[]) {
  std::cout << "TESTING csce240::two_dim::Vector CLASS" << std::endl;
  if (TestCreateTwoDimVector())
    std::cout << " TestCreateTwoDimVector PASSED" << std::endl;

  if (TestGetLengthOfTwoDimVector())
    std::cout << " TestGetLengthOfTwoDimVector PASSED" << std::endl;

  std::cout << "TESTING csce240::three_dim::Vector CLASS" << std::endl;
  if (TestCreateThreeDimVector())
    std::cout << " TestCreateThreeDimVector PASSED" << std::endl;

  if (TestGetLengthOfThreeDimVector())
    std::cout << " TestGetLengthOfThreeDimVector PASSED" << std::endl;

  return 0;
}
