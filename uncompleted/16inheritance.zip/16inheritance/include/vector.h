/* Copyright 2018 */
/* This pair of classes represent vectors in two and three space.
 * Classes contained:
 *  - csce240::two_dim::Vector
 *  - csce240::three_dim::Vector
 */
#ifndef _04HW_LIB_VECTOR_H_  // NOLINT
#define _04HW_LIB_VECTOR_H_  // NOLINT

#include <cmath>
// using sqrt
#include <iostream>
#include <string>

namespace csce240 {

namespace two_dim {
/* Represents a direction and magnitude in two dimensions, with dimensions
 *     unspecified.
 * Constructors:
 *  - default : returns the degenerate vector (zero length and no direction)
 *  - double, double : returns a direction and magnitude of the specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 * Methods:
 *  - GetLength : double
 *     returns the magnitude of the vector
 *  - ToString : std::string
 *
 * Accessors:
 *  - x() : double
 *  - y() : double
 */
class Vector {
 public:
  Vector() : x_(0.0), y_(0.0) {}
  Vector(double x, double y) : x_(x), y_(y) {}

  inline double x() const { return x_; }
  inline void x(double x) { x_ = x; }
  inline double y() const { return y_; }
  inline void y(double y) { y_ = y; }
  
  double GetLength() const;
  const std::string ToString() const;

  friend std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);
 private:
  double x_, y_;
};

std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);

}  // namespace two_dim
  
namespace three_dim {
/* Represents a direction and magnitude in three dimensions, with dimensions
 *     unspecified.
 * Constructors:
 *  - default : returns the degenerate vector (zero length and no direction)
 *  - double, double, double : returns a direction and magnitude of the
 *      specified tuple
 * Methods:
 *  - GetLength : double
 *     returns the magnitude of the vector
 *  - ToString : std::string
 *
 * Accessors:
 *  - x() : double
 *  - y() : double
 *  - z() : double
 */
 class Vector {
 public:
  Vector() : x_(0.0), y_(0.0), z_(0.0) {}
  Vector(double x, double y, double z) : x_(x), y_(y), z_(z) {}

  inline double x() const { return x_; }
  inline void x(double x) { x_ = x; }
  inline double y() const { return y_; }
  inline void y(double y) { y_ = y; }
  inline double z() const { return z_; }
  inline void z(double z) { z_ = z; }
  
  double GetLength() const;
  const std::string ToString() const;

  friend std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);
 private:
  double x_, y_, z_;
};
std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);

}  // namespace three_dim

}  // namespace csce240

#endif  // NOLINT
