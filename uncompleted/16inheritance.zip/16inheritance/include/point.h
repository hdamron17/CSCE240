/* Copyright 2018 */
/* This pair of classes represent points in two and three space.
 * Classes contained:
 */
#ifndef _04HW_LIB_POINT_H_  // NOLINT
#define _04HW_LIB_POINT_H_  // NOLINT

#include <cassert>
#include <iostream>
#include <string>

#include "../include/util.h"
#include "../include/vector.h"

namespace csce240 {

namespace two_dim {

/* Represents a point in two dimensions, with dimensions unspecified.
 * Constructors:
 *  - default : returns the origin of a dimension
 *  - double, double : returns a point at the specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 * Methods:
 *  - AddOffset
 *  - GetOffset
 * Operators:
 *  - two_dim::Point == two_dim::Point : bool
 *  - two_dim::Point != two_dim::Point : bool
 *  - std::ostream << two_dim::Point : std::ostream
 */
class Point {
 public:
  Point() : x_(0.0), y_(0.0) {}
  Point(double x, double y) : x_(x), y_(y) {}

  inline double x() const { return x_; }
  inline void x(double x) { x_ = x; }
  inline double y() const { return y_; }
  inline void y(double y) { y_ = y; }

  void AddOffset(const Vector* offset);
  void GetOffset(const Point* end, Vector* offset) const;
  
  bool operator==(const Point& rhs) const;
  bool operator!=(const Point& rhs) const;

  const std::string ToString() const;
  friend std::ostream& operator<<(std::ostream& lhs, const Point& rhs);

 private:
  double x_, y_;
};

std::ostream& operator<<(std::ostream& lhs, const Point& rhs);

}  // namespace two_dim

namespace three_dim {

/* Represents a point in three dimensions, with dimensions unspecified.
 * Constructors:
 *  - default : returns the origin of a dimension
 *  - double, double, double : returns a point at the specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 *  - z() : double
 * Methods:
 *  - AddOffset
 *  - GetOffset
 * Operators:
 *  - two_dim::Point == two_dim::Point : bool
 *  - two_dim::Point != two_dim::Point : bool
 *  - std::ostream << two_dim::Point : std::ostream
 */
class Point {
 public:
  Point() : x_(0.0), y_(0.0), z_(0.0) {}
  Point(double x, double y, double z) : x_(x), y_(y), z_(z) {}

  inline double x() const { return x_; }
  inline void x(double x) { x_ = x; }
  inline double y() const { return y_; }
  inline void y(double y) { y_ = y; }
  inline double z() const { return z_; }
  inline void z(double z) { z_ = z; }

  void AddOffset(const Vector* offset);
  void GetOffset(const Point* end, Vector* offset) const;

  const std::string ToString() const;

  bool operator==(const Point& rhs) const;
  bool operator!=(const Point& rhs) const;

  friend std::ostream& operator<<(std::ostream& lhs, const Point& rhs);

 private:
  double x_, y_, z_;
};

std::ostream& operator<<(std::ostream& lhs, const Point& rhs);

}  // namespace three_dim

}  // namespace csce240

#endif  // NOLINT
