/* Copyright 2018 */

#include <cmath>
// using sqrt
#include <iostream>

#include "../include/point.h"
#include "../include/vector.h"

bool TestCreateTwoDimVector() {
  csce240::two_dim::Vector v(1.0, 0.5);

  if (1.0 != v.x() || 0.5 != v.y()) {
    std::cout << " TestCreateTwoDimVector FAILED ";
    std::cout << "Expected (1.0, 0.5), Actual(";
    std::cout << v.x() << ", " << v.y() << ")" << std::endl;
    return false;
  }

  return true;
}

bool TestGetLengthOfTwoDimVector() {
  csce240::two_dim::Vector v(3.0, 4.0);

  if (5.0 != v.GetLength()) {
    std::cout << " TestGetLengthOfTwoDimVector FAILED ";
    std::cout << "Expected 5.0 " << "Actual " << v.GetLength() << std::endl;
    return false;
  }

  return true;
}

bool TestGetUnitOfTwoDimVector() {
  csce240::two_dim::Vector v1(3.0, 4.0);
  csce240::two_dim::Vector v2 = v1.GetUnit();

  if (3.0/5.0 != v2.x() || 4.0/5.0 != v2.y()) {
    std::cout << " TestGetUnitOfTwoDimVector FAILED ";
    std::cout << "Expected: " << csce240::two_dim::Vector(3.0/5.0, 4.0/5.0)
        << ", Actual: " << v2 << std::endl;

    return false;
  }

  return true;
}

bool TestScaleTwoDimVector() {
  csce240::two_dim::Vector v(1.0, 1.0);

  if ( 2.0 != v.Scale(2.0).x() || 2.0 != v.Scale(2.0).y()) {
    std::cout << " TestScaleTwoDimVector FAILED ";
    std::cout << "Expected: " << csce240::two_dim::Vector(2.0, 2.0)
        << ", Actual: " << v.Scale(2.0) << std::endl;

    return false;
  }

  return true;
}

bool TestCreateThreeDimVector() {
  csce240::three_dim::Vector v(1.0, 0.5, 0.22);

  if (1.0 != v.x() || 0.5 != v.y() || 0.22 != v.z()) {
    std::cout << " TestCreateThreeDimVector FAILED ";
    std::cout << "Expected: (1.0, 0.5, 0.22) Actual: (";
    std::cout << v.x() << ", " << v.y() << ", " << v.z() << ")" << std::endl;
    return false;
  }

  return true;
}

bool TestGetLengthOfThreeDimVector() {
  csce240::three_dim::Vector v(3.0, 4.0, 12.0);

  if (13.0 != v.GetLength()) {
    std::cout << " TestAddThreeDimVectorToVector FAILED ";
    std::cout << "Expected: 13, Actual: " << v.GetLength() << std::endl;
    return false;
  }

  return true;
}

bool TestGetUnitOfThreeDimVector() {
  csce240::three_dim::Vector v1(3.0, 4.0, 12.0);
  csce240::three_dim::Vector v2 = v1.GetUnit();

  if (3.0/13.0 != v2.x() || 4.0/13.0 != v2.y() || 12.0/13.0 != v2.z()) {
    std::cout << " TestGetUnitOfThreeDimVector FAILED ";
    std::cout << "Expected: "
        << csce240::three_dim::Vector(3.0/13.0, 4.0/13.0, 12.0/13.0)
        << ", Actual: " << v2 << std::endl;

    return false;
  }

  return true;
}

bool TestScaleThreeDimVector() {
  csce240::three_dim::Vector v(1.0, 1.0, 1.0);

  if ( 2.0 != v.Scale(2.0).x() || 2.0 != v.Scale(2.0).y()
      || 2.0 != v.Scale(2.0).z()) {
    std::cout << " TestScaleThreeDimVector FAILED ";
    std::cout << "Expected: " << csce240::three_dim::Vector(2.0, 2.0, 2.0)
        << ", Actual: " << v.Scale(2.0) << std::endl;

    return false;
  }

  return true;
}

int main(int argc, char* argv[]) {
  std::cout << "TESTING csce240::two_dim::Vector CLASS" << std::endl;
  if (TestCreateTwoDimVector())
    std::cout << " TestCreateTwoDimVector PASSED" << std::endl;

  if (TestGetLengthOfTwoDimVector())
    std::cout << " TestGetLengthOfTwoDimVector PASSED" << std::endl;

  if (TestGetUnitOfTwoDimVector())
    std::cout << " TestGetUnitOfTwoDimVector PASSED" << std::endl;

  if (TestScaleTwoDimVector())
    std::cout << " TestScaleTwoDimVector PASSED" << std::endl;


  std::cout << "TESTING csce240::three_dim::Vector CLASS" << std::endl;
  if (TestCreateThreeDimVector())
    std::cout << " TestCreateThreeDimVector PASSED" << std::endl;

  if (TestGetLengthOfThreeDimVector())
    std::cout << " TestGetLengthOfThreeDimVector PASSED" << std::endl;

  if (TestGetUnitOfThreeDimVector())
    std::cout << " TestGetUnitOfThreeDimVector PASSED" << std::endl;

  if (TestScaleThreeDimVector())
    std::cout << " TestScaleThreeDimVector PASSED" << std::endl;

  return 0;
}
