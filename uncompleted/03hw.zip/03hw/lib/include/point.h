/* Copyright 2018 */
/* This pair of classes represent points in two and three space.
 * Classes contained:
 *  - csce240::two_dim::Point
 *  - csce240::three_dim::Point
 */
#ifndef _03HW_LIB_POINT_H_  // NOLINT
#define _03HW_LIB_POINT_H_  // NOLINT

#include <iostream>
#include <string>

#include "../include/util.h"
#include "../include/vector.h"

namespace csce240 {

namespace two_dim {

/* Represents a point in two dimensions, with dimensions unspecified.
 * Constructors:
 *  - default : returns the origin of a dimension
 *  - double, double : returns a point at the specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 * Operators:
 *  - two_dim::Point + two_dim::Vector : two_dim::Point
 *  - two_dim::Point - two_dim::Point : two_dim::Vector
 *  - two_dim::Point == two_dim::Point : bool
 *  - two_dim::Point != two_dim::Point : bool
 *  - std::ostream << two_dim::Point : std::ostream
 */
class Point {
 public:
  Point() : x_(0.0), y_(0.0) {}
  Point(double x, double y) : x_(x), y_(y) {}

  inline double x() const { return x_; }
  inline double y() const { return y_; }

  const Point operator+(const Vector& rhs) const;
  const Vector operator-(const Point& rhs) const;
  bool operator==(const Point& rhs) const;
  bool operator!=(const Point& rhs) const;

  const std::string ToString() const;
  friend std::ostream& operator<<(std::ostream& lhs, const Point& rhs);
 private:
  double x_, y_;
};

std::ostream& operator<<(std::ostream& lhs, const Point& rhs);

}  // namespace two_dim

namespace three_dim {

/* Represents a point in three dimensions, with dimensions unspecified.
 * Constructors:
 *  - default : returns the origin of a dimension
 *  - double, double, double : returns a point at the specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 *  - z() : double
 * Operators:
 *  - three_dim::Point + three_dim::Vector : three_dim::Point
 *  - three_dim::Point - three_dim::Point : three_dim::Vector
 *  - three_dim::Point == three_dim::Point : bool
 *  - three_dim::Point != three_dim::Point : bool
 *  - std::ostream << three_dim::Point : std::ostream
 */
class Point {
 public:
  Point() : x_(0.0), y_(0.0), z_(0.0) {}
  Point(double x, double y, double z) : x_(x), y_(y), z_(z) {}


  inline double x() const { return x_; }
  inline double y() const { return y_; }
  inline double z() const { return z_; }

  const std::string ToString() const;

  const Point operator+(const Vector& rhs) const;
  const Vector operator-(const Point& rhs) const;
  bool operator==(const Point& rhs) const;
  bool operator!=(const Point& rhs) const;

  friend std::ostream& operator<<(std::ostream& lhs, const Point& rhs);
 private:
  double x_, y_, z_;
};

std::ostream& operator<<(std::ostream& lhs, const Point& rhs);

}  // namespace three_dim

}  // namespace csce240

#endif  // NOLINT
