/* Copyright 2018 */
/* This pair of classes represent vectors in two and three space.
 * Classes contained:
 *  - csce240::two_dim::Vector
 *  - csce240::three_dim::Vector
 */
#ifndef _03HW_LIB_VECTOR_H_  // NOLINT
#define _03HW_LIB_VECTOR_H_  // NOLINT

#include <cmath>
// using sqrt
#include <iostream>

namespace csce240 {

namespace two_dim {
/* Represents a direction and magnitude in two dimensions, with dimensions
 *     unspecified.
 * Constructors:
 *  - default : returns the degenerate vector (zero length and no direction)
 *  - double, double : returns a direction and magnitude of the specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 * GetLength() : double
 *     returns the magnitude of the vector
 * GetUnit() : two_dim::Vector
 *     returns a vector of magnitude 0
 * Operators:
 *  - two_dim::Vector * double : two_dim::Vector
 *  - double + two_dim::Vector : two_dim::Vector
 */
class Vector {
 public:
  Vector() : x_(0.0), y_(0.0) {}
  Vector(double x, double y) : x_(x), y_(y) {}

  inline double x() const { return x_; }
  inline double y() const { return y_; }
  
  double GetLength() const;

  const Vector GetUnit() const;

  const Vector Scale(double scalar) const;
  const Vector operator*(double rhs) const;
  
  friend const Vector operator*(double lhs, const Vector& rhs);
  friend std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);

 private:
  double x_, y_;
};  

std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);

}  // namespace two_dim
  
namespace three_dim {
/* Represents a direction and magnitude in three dimensions, with dimensions
 *     unspecified.
 * Constructors:
 *  - default : returns the degenerate vector (zero length and no direction)
 *  - double, double, double : returns a direction and magnitude of the
 *      specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 *  - z() : double
 * GetLength : double
 *     returns the magnitude of the vector
 * GetUnit : three_dim::Vector
 *     returns a vector of magnitude 0
 * Operators:
 *  - three_dim::Vector * double : three_dim::Vector
 *  - double + three_dim::Vector : three_dim::Vector
 */class Vector {
 public:
  Vector() : x_(0.0), y_(0.0), z_(0.0) {}
  Vector(double x, double y, double z) : x_(x), y_(y), z_(z) {}

  inline double x() const { return x_; }
  inline double y() const { return y_; }
  inline double z() const { return z_; }
  
  double GetLength() const;

  const Vector GetUnit() const;

  const Vector Scale(double scalar) const;
  const Vector operator*(double rhs) const;
  
  friend const Vector operator*(double lhs, const Vector& rhs);
  friend std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);
 private:
  double x_, y_, z_;
};

const Vector operator*(double lhs, const Vector& rhs);
std::ostream& operator<<(std::ostream& lhs, const Vector& rhs);

}  // namespace three_dim

}  // namespace csce240

#endif  // NOLINT
