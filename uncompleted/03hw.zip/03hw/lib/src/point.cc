#include "../include/point.h"

namespace csce240 {

namespace two_dim {

const Point Point::operator+(const Vector& rhs) const {
  return Point(x_ + rhs.x(), y_ + rhs.y());
}

const Vector Point::operator-(const Point& rhs) const {
  return Vector(x_ - rhs.x_, y_ - rhs.y_);
}

bool Point::operator==(const Point& rhs) const {
  return floating_point::equals(x_, rhs.x_)
      && floating_point::equals(y_, rhs.y_);
}

bool Point::operator!=(const Point& rhs) const {
  return !floating_point::equals(x_, rhs.x_)
      || !floating_point::equals(y_, rhs.y_);
}

const std::string Point::ToString() const {
  return "(" + std::to_string(x_) + ", " + std::to_string(y_) + ")";
}

std::ostream& operator<<(std::ostream& lhs, const Point& rhs) {
  lhs << "(" << rhs.x_ << ", " << rhs.y_ << ")";
  return lhs;
}

}  // namespace two_dim

namespace three_dim {

const Point Point::operator+(const Vector& rhs) const {
  return Point(x_ + rhs.x(), y_ + rhs.y(), z_ + rhs.z());
}

const Vector Point::operator-(const Point& rhs) const {
  return Vector(x_ - rhs.x_, y_ - rhs.y_, z_ - rhs.z_);
}

bool Point::operator==(const Point& rhs) const {
  return floating_point::equals(x_, rhs.x_)
      && floating_point::equals(y_, rhs.y_)
      && floating_point::equals(z_, rhs.z_);
}

bool Point::operator!=(const Point& rhs) const {
  return !floating_point::equals(x_, rhs.x_)
      || !floating_point::equals(y_, rhs.y_)
      || !floating_point::equals(z_, rhs.z_);
}

const std::string Point::ToString() const {
  return "(" + std::to_string(x_) + ", " + std::to_string(y_)
      + std::to_string(z_) + ")";
}

std::ostream& operator<<(std::ostream& lhs, const Point& rhs) {
  lhs << "(" << rhs.x_ << ", " << rhs.y_ << ", " << rhs.z_ << ")";
  return lhs;
}

}  // namespace three_dim

}  // namespace csce240
