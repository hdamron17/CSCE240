#include "../include/vector.h"

namespace csce240 {

namespace two_dim {

double Vector::GetLength() const {
  return sqrt(x_*x_ + y_*y_);
}

const Vector Vector::GetUnit() const {
  double length = GetLength();
  return Vector(x_ / length, y_ / length);
}

const Vector Vector::Scale(double scalar) const {
  return Vector(scalar * x_, scalar * y_);
}

const Vector Vector::operator*(double scalar) const {
  return Scale(scalar);
}

const Vector operator*(double lhs, const Vector& rhs) {
  return rhs.Scale(lhs);
}

std::ostream& operator<<(std::ostream& lhs, const Vector& rhs) {
  lhs << "(" << rhs.x_ << ", " << rhs.y_ << ")";

  return lhs;
}

}  // namespace two_dim

namespace three_dim {

double Vector::GetLength() const {
  return sqrt(x_*x_ + y_*y_ + z_*z_);
}

const Vector Vector::GetUnit() const {
  double length = GetLength();
  return Vector(x_ / length, y_ / length, z_ / length);
}

const Vector Vector::Scale(double scalar) const {
  return Vector(scalar * x_, scalar * y_, scalar * z_);
}

const Vector Vector::operator*(double scalar) const {
  return Scale(scalar);
}

const Vector operator*(double lhs, const Vector& rhs) {
  return rhs.Scale(lhs);
}

std::ostream& operator<<(std::ostream& lhs, const Vector& rhs) {
  lhs << "(" << rhs.x_ << ", " << rhs.y_ << ", " << rhs.z_ << ")";

  return lhs;
}

}  // namespace three_dim


}  // namespace csce240
