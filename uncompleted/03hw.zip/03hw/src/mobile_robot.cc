/* Copyright 2018 */
#include "../include/mobile_robot.h"  // NOLINT
