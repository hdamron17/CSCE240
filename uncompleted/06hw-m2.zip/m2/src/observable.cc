#include "observable.h"

namespace csce240 {

}
