#ifndef _04HW_INCLUDE_MOBILE_ROBOT_H_  // NOLINT
#define _04HW_INCLUDE_MOBILE_ROBOT_H_  // NOLINT

#include <cassert>
// using assert
#include <string>
#include <vector>

#include "point.h"

namespace csce240 {

class MobileRobot {
 public:
  MobileRobot();
  MobileRobot(double speed);
  virtual ~MobileRobot();

  double speed() const;

  const std::string id() const;
  bool id(const std::string& id);

  const Coordinate* location() const;

  virtual bool CanTranslateTo(const Coordinate* goal) const = 0;
  virtual void Translate(const Offset* direction) = 0;

  static bool IsUnique(const std::string& id);
 protected:
  double speed_;
  Coordinate *location_;
};

}  // namespace csce240

#endif  // NOLINT
