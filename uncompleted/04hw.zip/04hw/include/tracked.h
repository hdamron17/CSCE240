#ifndef _04HW_INCLUDE_TRACKED_H_  // NOLINT
#define _04HW_INCLUDE_TRACKED_H_  // NOLINT

#include "mobile_robot.h"
#include "point.h"
#include "util.h"
#include "vector.h"

namespace csce240 {

class Tracked : public MobileRobot {
 public:
  Tracked(const Coordinate* location);
  Tracked(const Coordinate* location, double speed);
  Tracked(const double x, const double y);
  Tracked(double x, double y, double speed);
  ~Tracked();

  bool CanTranslateTo(const Coordinate* goal) const;
  void Translate(const Offset* direction);
};

}  // namespace csce240

#endif  // NOLINT
