/* Copyright 2018 */
/* This pair of classes represent vectors in two and three space.
 * Classes contained:
 *  - csce240::two_dim::Vector
 *  - csce240::three_dim::Vector
 */
#ifndef _LIB_INCLUDE_VECTOR_H_  // NOLINT
#define _LIB_INCLUDE_VECTOR_H_  // NOLINT

#include <cassert>
#include <cmath>
// using sqrt
#include <iostream>
#include <string>

#include "util.h"

namespace csce240 {

/* Child classes only needed for accessors and mutators */
class Offset {
 public:
  virtual ~Offset() {};  // delete Offsets without warnings

  /* Returns magnitude of underlying vector */
  virtual double GetLength() const = 0;

  /* Returns true if this approximately equals that */
  virtual bool Equals(const Offset* that) const = 0;

  /* Stores a unit vector in the same direction as instance in unit */
  virtual void GetUnit(Offset* unit) const = 0;

  /* Stores copy of instance, scaled by scalar, in scaled. */
  virtual void Scale(double scalar, Offset* scaled) const = 0;

  /* Returns a string version of the vector using std::to_string */
  virtual const std::string ToString() const = 0;

  friend std::ostream& operator<<(std::ostream& lhs, const Offset& rhs);

 protected:
  virtual void ExtractTo(std::ostream& cout) const = 0;
};
std::ostream& operator<<(std::ostream& lhs, const Offset& rhs);

namespace two_dim {
/* Represents a direction and magnitude in two dimensions, with dimensions
 *     unspecified.
 * Constructors:
 *  - default : returns the degenerate vector (zero length and no direction)
 *  - double, double : returns a direction and magnitude of the specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 * Mutators:
 *  - x() : double
 *  - y() : double
 */
class Vector : public Offset {
 public:
  Vector() : x_(0.0), y_(0.0) {}
  Vector(double x, double y) : x_(x), y_(y) {}

  inline double x() const { return x_; }
  inline void x(double x) { x_ = x; }

  inline double y() const { return y_; }
  inline void y(double y) { y_ = y; }
  
  double GetLength() const;

  void GetUnit(Offset* unit) const;

  void Scale(double scalar, Offset* scaled) const;

  bool Equals(const Offset* that) const;

  const std::string ToString() const;

 protected:
  void ExtractTo(std::ostream& cout) const;
  const Vector* ToVector(const Offset* that) const;

 private:
  double x_, y_;
};

}  // namespace two_dim
  
namespace three_dim {
/* Represents a direction and magnitude in three dimensions, with dimensions
 *     unspecified.
 * Constructors:
 *  - default : returns the degenerate vector (zero length and no direction)
 *  - double, double, double : returns a direction and magnitude of the
 *      specified tuple
 * Accessors:
 *  - x() : double
 *  - y() : double
 *  - z() : double
 * Mutators:
 *  - x() : double
 *  - y() : double
 *  - z() : double
 */
 class Vector : public Offset {
 public:
  Vector() : x_(0.0), y_(0.0), z_(0.0) {}
  Vector(double x, double y, double z) : x_(x), y_(y), z_(z) {}

  inline double x() const { return x_; }
  inline void x(double x) { x_ = x; }

  inline double y() const { return y_; }
  inline void y(double y) { y_ = y; }

  inline double z() const { return z_; }
  inline void z(double z) { z_ = z; }
  
  double GetLength() const;

  bool Equals(const Offset* that) const;

  void GetUnit(Offset* unit) const;

  void Scale(double scalar, Offset* scaled) const;

  const std::string ToString() const;

 protected:
  void ExtractTo(std::ostream& cout) const;
  const Vector* ToVector(const Offset* that) const;

 private:
  double x_, y_, z_;
};

}  // namespace three_dim

}  // namespace csce240

#endif  // NOLINT
