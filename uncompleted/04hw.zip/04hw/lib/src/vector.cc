#include "vector.h"

namespace csce240 {

std::ostream& operator<<(std::ostream& lhs, const Offset& rhs) {
  rhs.ExtractTo(lhs);

  return lhs;
}

namespace two_dim {

const Vector* Vector::ToVector(const Offset* that) const {
  const Vector *vector = dynamic_cast<const Vector *>(that);
  assert(vector);

  return vector;
}

double Vector::GetLength() const {
  return sqrt(x_*x_ + y_*y_);
}

bool Vector::Equals(const Offset* that) const {
  const Vector *vector = ToVector(that);

  return floating_point::Equals(x_, vector->x_)
      && floating_point::Equals(y_, vector->y_);
}

void Vector::GetUnit(Offset* that) const {
  Vector *vector = const_cast<Vector *>(ToVector(that));

  double magnitude = that->GetLength();
  vector->x_ = vector->x_ / magnitude;
  vector->y_ = vector->y_ / magnitude;
}

void Vector::Scale(double scalar, Offset* scaled) const {
  Vector *vector = const_cast<Vector *>(ToVector(scaled));

  vector->x_ *= scalar;
  vector->y_ *= scalar;
}

const std::string Vector::ToString() const {
  return "(" + std::to_string(x_) + ", " + std::to_string(y_) + ")";
}

void Vector::ExtractTo(std::ostream& cout) const {
  cout << "(" << x_ << ", " << y_ << ")";
}

}  // namespace two_dim

namespace three_dim {

const Vector* Vector::ToVector(const Offset* that) const {
  const Vector *vector = dynamic_cast<const Vector *>(that);
  assert(vector);

  return vector;
}

double Vector::GetLength() const {
  return sqrt(x_*x_ + y_*y_ + z_*z_);
}

bool Vector::Equals(const Offset* that) const {
  const Vector *vector = dynamic_cast<const Vector *>(that);
  assert(vector);

  return floating_point::Equals(x_, vector->x_)
      && floating_point::Equals(y_, vector->y_)
      && floating_point::Equals(z_, vector->z_);
}

void Vector::GetUnit(Offset* that) const {
  Vector *vector = const_cast<Vector *>(ToVector(that));

  double magnitude = that->GetLength();
  vector->x_ = vector->x_ / magnitude;
  vector->y_ = vector->y_ / magnitude;
  vector->z_ = vector->z_ / magnitude;
}

void Vector::Scale(double scalar, Offset* scaled) const {
  Vector *vector = const_cast<Vector *>(ToVector(scaled));

  vector->x_ *= scalar;
  vector->y_ *= scalar;
  vector->z_ *= scalar;
}

const std::string Vector::ToString() const {
  return "(" + std::to_string(x_) + ", " + std::to_string(y_)
      + ", " + std::to_string(z_) + ")";
}

void Vector::ExtractTo(std::ostream& cout) const {
  cout << "(" << x_ << ", " << y_ << ", " << z_ << ")";
}

}  // namespace three_dim


}  // namespace csce240
