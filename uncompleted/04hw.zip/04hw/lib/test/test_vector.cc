/* Copyright 2018 */

#include <cmath>
// using sqrt
#include <iostream>

#include "../include/point.h"
#include "../include/vector.h"

using namespace csce240;

bool TestCreateTwoDimVector() {
  two_dim::Vector v(1.0, 0.5);

  if (1.0 != v.x() || 0.5 != v.y()) {
    std::cout << " TestCreateTwoDimVector FAILED "
        << "Expected (1.0, 0.5), Actual: " << v << std::endl;
    return false;
  }

  return true;
}

bool TestCreateThreeDimVector() {
  three_dim::Vector v(1.0, 0.5, 0.22);

  if (1.0 != v.x() || 0.5 != v.y() || 0.22 != v.z()) {
    std::cout << " TestCreateThreeDimVector FAILED "
        << "Expected: (1.0, 0.5, 0.22) Actual: " << v << std::endl;
    return false;
  }

  return true;
}

bool TestGetLengthOfOffset(const csce240::Offset& o, double expected) {
  if (expected != o.GetLength()) {
    std::cout << " TestGetLengthOfOffset FAILED "
        << "Expected: " << expected << ", Actual: "
        << o.GetLength() << std::endl;
    return false;
  }

  return true;
}


int main(int argc, char* argv[]) {
  std::cout << "TESTING csce240::two_dim::Vector CLASS" << std::endl;
  if (TestCreateTwoDimVector())
    std::cout << " TestCreateTwoDimVector PASSED" << std::endl;

  std::cout << "TESTING csce240::three_dim::Vector CLASS" << std::endl;
  if (TestCreateThreeDimVector())
    std::cout << " TestCreateThreeDimVector PASSED" << std::endl;

  std::cout << "TESTING csce240::Offset CLASS inheritance" << std::endl;
  if (TestGetLengthOfOffset(two_dim::Vector(3.0, 4.0), 5.0))
    std::cout << " TestGetLengthOfTwoDimVector PASSED" << std::endl;

  if (TestGetLengthOfOffset(three_dim::Vector(3.0, 4.0, 12.0), 13.0))
    std::cout << " TestGetLengthOfThreeDimVector PASSED" << std::endl;

  return 0;
}
