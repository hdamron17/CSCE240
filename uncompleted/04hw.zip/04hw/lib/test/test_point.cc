/* Copyright 2018 */

#include <iostream>

#include "../include/point.h"
#include "../include/vector.h"

using namespace csce240;

bool TestCreateTwoDimPoint() {
  two_dim::Point p(1.0, 0.5);

  if (1.0 != p.x() || 0.5 != p.y()) {
    std::cout << " TestCreateTwoDimPoint FAILED "
        << "Expected: (1.0, 0.5), Actual: " << p << std::endl;
    return false;
  }

  return true;
}

bool TestCreateThreeDimPoint() {
  three_dim::Point p(1.0, 0.5, 0.22);

  if (1.0 != p.x() || 0.5 != p.y() || 0.22 != p.z()) {
    std::cout << " TestCreateThreeDimPoint FAILED "
        << "Expected: (1.0, 0.5), Actual: " << p << std::endl;
    return false;
  }

  return true;
}

bool TestAddOffsetToCoordinate(const Offset& offset, const Coordinate& expected,
    Coordinate* coord) {
  coord->AddOffset(&offset);

  if (!coord->Equals(&expected)) {
    std::cout << " TestAddOffsetToCoordinate FAILED "
        << "Expected: " << expected << ", Actual: " << *coord << std::endl;
    return false;
  }

  return true;
}

bool TestGetOffsetFromCoordinate(const Coordinate& start,
    const Coordinate& end, const Offset& expected, Offset* actual) {
  start.GetOffset(&end, actual);

  if (!expected.Equals(actual)) {
    std::cout << " TestGetOffsetFromCoordinate FAILED "
        << "Expected: " << expected << ", Actual: " << *actual << std::endl;
    return false;
  }

  return true;
}

int main(int argc, char* argv[]) {
  std::cout << "TESTING csce240::two_dim::Point CLASS" << std::endl;
  if (TestCreateTwoDimPoint())
    std::cout << " TestCreateTwoDimPoint PASSED" << std::endl;

  std::cout << "TESTING csce240::three_dim::Point CLASS" << std::endl;
  if (TestCreateThreeDimPoint())
    std::cout << " TestCreateThreeDimPoint PASSED" << std::endl;

  std::cout << "TESTING csce240::Coordinate CLASS inheritance" << std::endl;
  if (TestAddOffsetToCoordinate(two_dim::Vector(2.0, 1.0),
      two_dim::Point(3.0, 3.0), new two_dim::Point(1.0, 2.0)))
    std::cout << " TestAddOffsetToCoordinate PASSED" << std::endl;

  if (TestGetOffsetFromCoordinate(two_dim::Point(1.0, 1.0),
      two_dim::Point(0.0, 0.0), two_dim::Vector(-1.0, -1.0),
      new two_dim::Vector()))
    std::cout << " TestGetOffsetFromCoordinate PASSED" << std::endl;

  if (TestAddOffsetToCoordinate(three_dim::Vector(2.0, 1.0, 2.5),
      three_dim::Point(3.0, 3.0, 3.0), new three_dim::Point(1.0, 2.0, 0.5)))
    std::cout << " TestAddOffsetToCoordinate PASSED" << std::endl;

  if (TestGetOffsetFromCoordinate(three_dim::Point(1.0, 1.0, -1.0),
      three_dim::Point(0.0, 0.0, 0.0), three_dim::Vector(-1.0, -1.0, 1.0),
      new three_dim::Vector()))
    std::cout << " TestGetOffsetFromCoordinate PASSED" << std::endl;

  return 0;
}
