/* Copyright 2018 */

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <vector>
using std::vector;

#include "stack.h"
using csce240::IntStack;

void PrintVector(const vector<int>& vec) {
  for (unsigned int i = 0; i < vec.size(); ++i) {
    cout << "vec[" << i << "] : " << vec.at(i) << endl;
  }
}

void FillVector(vector<int>* vec, unsigned int size) {
  for (unsigned int i = 0; i < size; ++i) {
    vec->push_back(i);
  }
}

int main(int argc, char* argv[]) {
  return 0;
}
