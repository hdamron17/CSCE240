/* Copyright 2018 */

#include "stack.h"  // NOLINT

namespace csce240 {

int IntStack::at(int i) const {
  assert(-1 < i && i <= static_cast<int>(vector<int>::size()));
  
  return vector<int>::at(i);
}

int IntStack::size() const {
  return static_cast<int>(vector<int>::size());
}


}  // namespace csce240

