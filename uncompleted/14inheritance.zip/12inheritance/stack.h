/* Copyright 2018 */
#ifndef _240_LECT_12INHERITANCE_STACK_H_  // NOLINT
#define _240_LECT_12INHERITANCE_STACK_H_  // NOLINT

#include <iostream>
#include <cassert>
#include <vector>

namespace csce240 {

class IntStack : public std::vector<int>  {
public:
  /* create necessary constructors */

  /* redefine int at(int) and int size() methods */
  
protected:
  /* add functionality to backup when elems are popped (don't forget copy) */
};

/* create protected and private stack */

}  // namespace csce240

#endif  // NOLINT
