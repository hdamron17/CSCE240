/* Copyright 2018 */

// Include the iostream system lib for cin, cout, and endl

// Introduce qualified names for cin, cout, and endl, to file's global scope

int main(int argc, char *argv[]) {
  // Use single expression to display
  // "Hello Reader.
  // Welcome to C++"

  double gpa; // a double precision floating point value
  // Prompt user to enter percent GPA from CSCE146 and accept input on the same
  // line.

  // Get value from console buffer into gpa variable

  // Use selection statement to
  //  Display:
  //   "That cannot be correct."
  //  and return 1 from main when value is negative,

  //  Display:
  //  "What are you doing here?!"
  //  when gpa is less than a 70, and

  //  Display:
  //   "Welcome to Software Development."
  //  when gpa is 70.0 or greater.

  unsigned short langs; // an unsigned short value
  // Prompt user with
  //  "How many programming languages have you used? "
  // without a newline.

  // Get value from console input and move into langs variable

  // Use selection statement to
  //  Display
  //   "I thought you said you passed Java..."
  //  and return a 1 from main when langs value is 0,

  //  Display "This class may be challenging<newline>" when langs value is 1,
 
  //  Display "This class will be fun<newline>" when langs value is 2,

  //  Display
  //   "This class might be interesting<newline>"
  //  when langs value is 3, and

  //  Display
  //   "Easy mode"
  //  otherwise

  return 0; // return 0 for correct exit
}
