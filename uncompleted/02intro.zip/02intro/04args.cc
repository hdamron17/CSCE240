// Include header for iostream system library

// Introduce cout and endl from std namespace into file's name scope


int main(int argc, char* argv[]) {
  // When no arguments are provided to program,
  // - Give user message stating such and
  // - Exit program with a 1

  // Use definite loop to print all arguments, one per line.

  return 0;
}
