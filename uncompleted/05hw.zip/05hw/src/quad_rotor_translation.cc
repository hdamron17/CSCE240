/* Copyright 2018 */
#include "quad_rotor_translation.h"

