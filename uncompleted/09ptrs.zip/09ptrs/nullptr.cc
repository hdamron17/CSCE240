#include "nullptr.h"

int main(int argc, char* argv[]) {
  int a=3, b=4;
  int *x=NULL, *y=NULL;

  x = &a;
  y = &b;

  cout << "pow(" << a << ", "<< b << "): " << Pow(a, b) << endl;
  cout << "pow(" << x << ", " << y << "): " << Pow(*x, *y) << endl;

  return 0;
}

int Pow(int a, int b) {
  int pow = a;
  for (int i = 1; i < b; ++i) {
    pow *= a;
  }

  return pow;
}
int Pow(int *a, int *b) {
  int *pow = new int(*a);

  for (int i = 1; i < (b ? *b : 0); ++i) {
    *pow *= *a;
  }

  *a = *pow;
  delete pow;
  return *a;
}
