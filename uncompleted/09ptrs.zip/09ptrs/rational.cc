#include "rational.h"

int Rational::conversion_precision_ = 6;

Rational::Rational(int num, int den) : num_(num), den_(den), nan_(0 == den) {};

const Rational Rational::ToRational(double val) {
  if (isnan(val)) {
    return Rational(0, 0);
  }

  int num = pow(10, Rational::conversion_precision_);

  Rational r(val*num, num);

  return r.Simplify();
}

const Rational Rational::AddOp(const Rational& rhs) const {
  if (nan_ || rhs.nan_)
    return Rational(0, 0);

  // den is product of rhs and lhs denominators
  int den = den_ * rhs.den_;
  // numerators are multiplied by others' denominator
  int num_lhs = num_ * rhs.den_;
  int num_rhs = rhs.num_ * den_;

  // sum new numerators and simplify
  return Rational(num_lhs + num_rhs, den).Simplify();
}

const Rational Rational::MulOp(const Rational& rhs) const {
  if (nan_ || rhs.nan_)
    return Rational(0, 0);

  return Rational(num_*rhs.num_, den_*rhs.den_).Simplify();
}

const Rational Rational::operator+(const Rational& rhs) const {
  return AddOp(rhs);
}

const Rational Rational::operator*(const Rational& rhs) const {
  return MulOp(rhs);
}

const Rational Rational::Simplify() const {
  int gcd = CalcGCD(num_, den_);

  return Rational(num_ / gcd, den_ / gcd);
}

// Taken from https://en.wikipedia.org/wiki/Euclidean_algorithm 02.13.2018
int Rational::CalcGCD(int a, int b) const {
  int t = 0;
  a = abs(a);
  b = abs(b);

  while (0 != b) {
     t = b;
     b = a % b;
     a = t;
  }

  return a;
}

const String Rational::ToString() const {
  if (!nan_) {
    return to_string(num_) + "/" + to_string(den_);
  }
  else {
    return "nan";
  }
}

long double Rational::ToFloat() const {
  if (!nan_) {
    return static_cast<long double>(num_) / static_cast<long double>(den_);
  }
  else {
    return NAN;
  }
}

istream& operator >>(istream& in, Rational& rhs) {
  int num=0, den=0;
  char bar='\\';

  in >> num >> bar >> den;
  rhs.num_ = num;
  rhs.den_ = den;
  rhs.nan_ = 0 == den;

  return in;
}

ostream& operator<<(ostream& out, const Rational& rhs) {
  out << rhs.ToString();

  return out;
}

