/*
 * Copyright 2018
 */

#include <iostream>
using std::cout;
using std::endl;

#include <cstdlib>
// using rand
// using srand

int main(int argc, char** argv) {
  // seed random number gen with a const literal 123
  srand(123);
  // create two const ints for kRows and columns of matrix
  const int kRows = 4;
  const int cols = 3;

  // reseed random number gen with 123
  srand(123);
  // create dynamic int matrix twice as large
  int **m = new int*[2*kRows];
  // and assign each element a random [1, 100]
  for (int i = 0; i < 2*kRows; ++i) {
    m[i] = new int[2*cols];

    for (int j = 0; j < 2*cols; ++j)
      m[i][j] = rand() % 101 + 1;  // NOLINT
  }

  // print matrix
  for (int i = 0; i < 2*kRows; ++i) {
    for (int j = 0; j < 2*cols; ++j)
      cout << m[i][j] << '\t';

    cout << endl;
  }

  delete [] m;

  return 0;
}
