/* Copyright 2018
 * 
 * The nullptr pointer literal
 */
#ifndef _LECT_09PTRS_NULLPTR_H_  // NOLINT
#define _LECT_09PTRS_NULLPTR_H_  // NOLINT

#include <iostream>
using std::cout;
using std::endl;

int Pow(int a, int b);
int Pow(int *a, int *b);

#endif  // NOLINT
