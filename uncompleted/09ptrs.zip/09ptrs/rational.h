/* Copyright 2018 */

#ifndef _LECT_09PTRS_RATIONAL_H_
#define _LECT_09PTRS_RATIONAL_H_

#include <cctype>
using std::isdigit;
#include <cmath>
// using abs
// using pow
// using NAN
#include <iostream>
using std::istream;
using std::ostream;
#include <string>
using std::to_string;

typedef std::string String;

/* Rational class definition */
class Rational {
public:
  Rational(int num = 0, int den = 1);

  // approximates Rational value from floating point via conversion_precision_
  static const Rational ToRational(double val);
  inline static int conversion_precision(void) {
    return Rational::conversion_precision_;
  };
  inline static void conversion_precision(int conversion_precision) {
    if (0 < conversion_precision)
      Rational::conversion_precision_ = conversion_precision;
  };

  /* arithmetic methods and operators for Rational class
   *
   * - all arithmetic returns simplified Rationals
   * - all arithmetic involving nan Rationals return a nan Rational
   */
  const Rational AddOp(const Rational& rhs) const;
  const Rational MulOp(const Rational& rhs) const;

  // overloaded operators call the above arithmetic ops
  const Rational operator+(const Rational& rhs) const;
  const Rational operator*(const Rational& rhs) const;

  // uses Euclid's Algorithm for greatest common factor
  const Rational Simplify() const;

  // ToString and ToFloat methods return nan, appropriately
  const String ToString() const;
  long double ToFloat() const;

  // string output format: "int/int"
  friend istream& operator>>(istream& in, Rational& rhs);
  // string input format "int[:space:]*/[:space:]*int"
  friend ostream& operator<<(ostream& out, const Rational& rhs);

  // getters, no setters; create new Rationals, do not modify existing
  inline int num() const { return num_; };
  inline int den() const { return den_; };
  inline bool is_nan() const { return nan_; };
private:
  static int conversion_precision_;  // precision for double to rational

  // implements Euclid's division-based method
  int CalcGCD(int a, int b) const; // returns GCD of a and b

  int num_;
  int den_;
  bool nan_;
};

#endif
