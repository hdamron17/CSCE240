/* Copyright 2018
 * 
 * Introduction to pointers
 */
#ifndef _LECT_09PTRS_INTRO_H_  // NOLINT
#define _LECT_09PTRS_INTRO_H_  // NOLINT

#include <iostream>
using std::cout;
using std::endl;

void Swap(int* a, int* b);
void ConstSwap(const int* a, const int* b);

#endif  // NOLINT
