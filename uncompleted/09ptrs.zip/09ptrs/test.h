/* Copyright 2018 */

#ifndef LECT_07INTRO_TEST_H_  // NOLINT
#define LECT_07INTRO_TEST_H_  // NOLINT

#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <string>
typedef std::string String;
#include <sstream>
typedef std::stringstream StrStream;

#include "rational.h"

void Run(bool result, int& passed, int& failed);

bool TestRationalCreation(const String& align);
bool TestRationalToRational(const String& align);
bool TestRationalSimplify(const String& align);
bool TestRationalAddOp(const String& align);
bool TestRationalMulOp(const String& align);
bool TestRationalToString(const String& align);
bool TestRationalToFloat(const String& align);
bool TestRationalInsertionOp(const String& align);
bool TestRationalExtractionOp(const String& align);

#endif  // NOLINT
