/*
 * Copyright 2018
 */

#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(int argc, char** argv) {
  // create an int pointer to hold a dynamic array
  int *a = nullptr;

  // prompt user for the size of the array
  int size = 0;
  cout << "Enter array size: ";
  cin >> size;
  // request memory for an array of given size
  a = new int[size];

  // fill array with integers from 1 to size
  for (int i = 0; i < size; ++i) {
    a[i] = i + 1;  // change to pointer arithmetic
  }

  // double array, while retaining the original values
  int *b = new int[2*size];
  for (int i = 0; i < size; ++i) {
    cout << a[i];  // change to pointer arithmetic
  }

  return 0;
}
