/* Copyright 2018 */

#ifndef _LECT_10PTRS_RATIONAL_H_
#define _LECT_10PTRS_RATIONAL_H_

#include <cctype>
using std::isdigit;
#include <cmath>
// using abs
// using pow
// using NAN
#include <iostream>
using std::istream;
using std::ostream;
#include <string>
using std::to_string;

typedef std::string String;

/* Rational class definition */
class Rational {
public:
  Rational(void) : num_(nullptr), den_(nullptr), nan_(new bool(true)) {};
  Rational(int num = 0, int den = 1);
  /*
   * Discuss deep vs shallow copy and implement the copy constructor
   *  - Show the destructor problem with shallow copies.
   */
  Rational(const Rational& copy);
  /* Discuss destructors and implement */
  ~Rational(void);

  // approximates Rational value from floating point via conversion_precision_
  static const Rational ToRational(double val); /* Check value */
  inline static int conversion_precision(void) {
    return Rational::conversion_precision_;
  };
  inline static void conversion_precision(int conversion_precision) {
    if (0 < conversion_precision)
      Rational::conversion_precision_ = conversion_precision;
  };

  // arithmetic methods and operators for Rational class
  //  
  //  - all arithmetic returns simplified Rationals
  //  - all arithmetic involving nan Rationals return a nan Rational
   
  const Rational AddOp(const Rational& rhs) const;
  const Rational AddOp(double rhs) const;
  const Rational AddOp(int rhs) const;

  const Rational MulOp(const Rational& rhs) const;
  const Rational MulOp(double rhs) const;
  const Rational MulOp(int rhs) const;

  // overloaded operators call the above arithmetic ops
  const Rational operator+(const Rational& rhs) const;
  const Rational operator+(double rhs) const;
  const Rational operator+(int rhs) const;

  const Rational operator*(const Rational& rhs) const;
  const Rational operator*(double rhs) const;
  const Rational operator*(int rhs) const;

  /* Discuss comparison and implement */
  bool LtEq(const Rational& rhs) const;
  bool LtEq(double rhs) const;
  bool LtEq(int lhs) const;

  bool operator<=(const Rational& rhs) const;
  bool operator<=(double rhs) const;
  bool operator<=(int rhs) const;

  /*
   * Discuss deep vs shallow copy and implement assignment operator
   *  - Show why we return object reference, rather than void
   */
  const Rational& operator=(const Rational& rhs);

  // uses Euclid's Algorithm for greatest common factor
  const Rational Simplify() const;

  // ToString and ToFloat methods return nan, appropriately
  const String ToString() const;
  long double ToFloat() const;

  // string output format: "int/int"
  friend istream& operator>>(istream& in, Rational& rhs);
  // string input format "int[:space:]*/[:space:]*int"
  friend ostream& operator<<(ostream& out, const Rational& rhs);

  // getters, no setters; create new Rationals, do not modify existing
  inline int num() const;
  inline int den() const;
  inline bool is_nan() const;
private:
  // method to decide approximate equality
  bool FpEq(double a, double b) const;

  static int conversion_precision_;  // precision for double to rational

  // implements Euclid's division-based method
  int CalcGCD(int a, int b) const; // returns GCD of a and b

  int *num_;
  int *den_;
  bool nan_;
};

#endif
