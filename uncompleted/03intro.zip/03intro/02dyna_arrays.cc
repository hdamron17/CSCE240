/*
 * Copyright 2018
 * Created by Jeremy S Lewis
 */

#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(int argc, char** argv) {
  // create an int pointer to hold a dynamic array

  // prompt user for the size of the array

  // request memory for an array of given size

  // fill array with integers from -100 to -100 + size

  // double array, while retaining the original values

  // half array while retaining the original size / 2 values

  return 0;
}
