/*
 * Copyright 2018
 * Created by Jeremy S Lewis
 */

#include <iostream>
using std::cout;
using std::endl;

#include <cstdlib>
// using rand
// using srand

int main(int argc, char** argv) {
  // seed random number gen with a const literal 123

  // create two const ints for kRows and columns of matrix

  // create int matrix and assign each element a random [1, 100]

  // print int matrix

  // reseed random number gen with 123
  // create dynamic int matrix twice as large
  // and assign each element a random [1, 100]

  // print matrix

  return 0;
}
