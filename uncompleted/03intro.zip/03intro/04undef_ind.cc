/*
 * Copyright 2018
 * Created by Jeremy S Lewis
 */

#include <iostream>
using std::cout;
using std::endl;

#include <array>
using std::array;


int main(int argc, char** argv) {
  // create double array from initializer list of 4 floating point literals
  // tab and display elements from positions -1 to 4, by 1 using []

  // create a class array obj of type double and const size 4, reuse literals
  // tab and display elements from positions -1 to 4, by 1 using []

  // tab and display elements from positions -1 to 4, by 1 using array::at

  return 0;
}
