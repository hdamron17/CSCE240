/*
 * Copyright 2018
 * Created by Jeremy S Lewis
 */

#include <iostream>
using std::cout;
using std::endl;

// write hello world function which displays just that

int main(int argc, char* argv[]) {
  // call hello world function

  return 0;
}
