/*
 * Copyright 2018
 * Created by Jeremy S Lewis
 */

#include <iostream>
using std::cout;
using std::endl;

int main(int argc, char** argv) {
  // create a const int to hold the size of the array
  // use the const int to create an array

  // store integers 1 to n in the array, where n is the size of the array

  // determine the sum of the n integers stored in the array
  // display the sum

  // create a second array and copy each value, doubled, from the first

  // display both arrays, 1 element of each per line, tab delimited

  return 0;
}
