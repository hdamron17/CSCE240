/* Copyright 2018 */

// Include the C limits system library for INT_MAX const variable

// Include the iostream system library for cout and endl.
// Introduce cout and endl from the std namespace to this file's scope.

/**
 * Main method. Required entry point for all C++ executables.
 */
int main(int args, char *argv[]) {
  // Create a constant char variable to for the printable tab character.

  // Create a signed int variable and assign it the largest signed int for
  //    this machine.
  // Display the message "s_int:<tab><s_int value><newline>"
  // Display the message "s_int:<tab><s_int value> + 1<newline>"

  // Create an usigned int variable and assign it s_int's value with a static
  //    cast.
  // Display the message "u_int:<tab><u_int value><newline>"
  // Display the message "u_int:<tab><u_int value> + 1<newline>"

  // Create a boolean and assign it the value of u_int + u_int - 2.0*s_int == 0
  // Display "u_int + u_int - 2.0*s_int == 0 : <truth_value><newline>"

  // Create a single precision floating point value called garbage
  // Display garbage's value as "garbage value is <garbage_value><newline>"
}

