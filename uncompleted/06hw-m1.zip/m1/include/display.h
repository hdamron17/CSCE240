#ifndef _06HW_INCLUDE_DISPLAY_H_
#define _06HW_INCLUDE_DISPLAY_H_

namespace csce240 {

class Display {

};

}  // namespace csce240

#define
