#include "average_temp_display.h"

namespace csce240 {

}  // namespace csce240
