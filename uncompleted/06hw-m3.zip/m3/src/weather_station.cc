#include "weather_station.h"

namespace csce240 {

}  // namespace csce240

