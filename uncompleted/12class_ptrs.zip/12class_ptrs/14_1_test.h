/* Copyright 2018 */
#ifndef LECT_12CLASS_PTRS_14_1_TEST_H_  // NOLINT
#define LECT_12CLASS_PTRS_14_1_TEST_H_  // NOLINT

#include <ctime>
// using time
#include <cstdlib>
// using rand
// using srand
#include <iostream>
using std::cout;
using std::endl;
#include <string>
using std::to_string;
typedef std::string String;
#include <sstream>
typedef std::stringstream StrStream;

#include "stack.h"  // NOLINT

/* Use to log result of Unit Test in passed and failed vars */
void Run(bool result, int* passed, int* failed);

/* Generates a random string of n characters from [A-Z] */
const String RandString(int n);

#endif  // NOLINT
