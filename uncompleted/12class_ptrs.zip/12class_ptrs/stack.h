/* Copyright 2018 */
#ifndef LECT_12CLASS_PTRS_STACK_H_  // NOLINT
#define LECT_12CLASS_PTRS_STACK_H_  // NOLINT

#include "dyn_str_array.h"  // NOLINT

class Stack;

#endif  //NOLINT
