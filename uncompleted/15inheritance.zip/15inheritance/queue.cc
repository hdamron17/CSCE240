/* Copyright 2018 */

#include "queue.h"  // NOLINT

namespace csce240 {

bool IntQueue::Empty() const {
  return true;
}

int IntQueue::Peek() const {
  return 0;
}

int IntQueue::Pop() {
  return 0;
}


void IntQueue::Push(int elem) {
}

}  // namespace csce240

