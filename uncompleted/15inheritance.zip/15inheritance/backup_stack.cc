/* Copyright 2018 */

#include "backup_stack.h"  // NOLINT

namespace csce240 {

int BackupIntStack::Pop() {
  return IntStack::Pop();
}

}  // namespace csce240

