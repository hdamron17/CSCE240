/* Copyright 2018 */

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <string>
using std::stoi;
#include <vector>
using std::vector;

#include "backup_stack.h"
#include "stack.h"

using csce240::BackupIntStack;
using csce240::IntStack;

void EmptyStack(IntStack* stack) {
  while (!stack->Empty()) {
    cout << "IntStack::Pop(): " << stack->Pop() << endl;
  }
}

void EmptyBackupStack(BackupIntStack* stack) {
  while (!stack->Empty()) {
    cout << "BackupIntStack::Pop(): " << stack->Pop() << endl;
  }
}

void FillVector(unsigned int size, vector<int>* vec) {
  for (unsigned int i = 0; i < size; ++i) {
    vec->push_back(i);
  }
}

void FillStack(int size, IntStack* stack) {
  for (int i = 0; i < size; ++i) {
    stack->Push(i);
  }
}

int main(int argc, char* argv[]) {
  IntStack stack;
  FillVector(5, &stack);
  BackupIntStack b_stack;
  FillVector(5, &b_stack);

  EmptyStack(&stack);
  EmptyBackupStack(&b_stack);

  return 0;
}
