/* Copyright 2018 */
#ifndef _240_LECT_12INHERITANCE_STACK_H_  // NOLINT
#define _240_LECT_12INHERITANCE_STACK_H_  // NOLINT

#include <iostream>
#include <cassert>
#include <vector>

namespace csce240 {

class IntStack : public std::vector<int>  {
public:
  /* create necessary constructors */
  IntStack() : std::vector<int>() {}
  IntStack(const std::vector<int>& vec) : std::vector<int>(vec) {}

  bool Empty() const;

  int Peek() const;
  int Pop();
  void Push(int elem);

  /* redefine int at(int) and int size() methods */
  int at(int index) const;
  int size() const;
};

}  // namespace csce240

#endif  // NOLINT
