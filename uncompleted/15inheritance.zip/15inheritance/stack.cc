/* Copyright 2018 */

#include "stack.h"  // NOLINT

namespace csce240 {

bool IntStack::Empty() const {
  return 0 == std::vector<int>::size();
}

int IntStack::Peek() const {
  assert(0 < size());

  return at(size() - 1);
}

int IntStack::Pop() {
  assert(0 < size());

  int tmp = at(size() - 1);  // could use vector::back() instead
  erase(begin() + size() - 1);
  return tmp;
}


void IntStack::Push(int elem) {
  push_back(elem);
}

int IntStack::at(int index) const {
  assert(-1 < index && index < size());

  return std::vector<int>::at(index);
}

int IntStack::size() const {
  return static_cast<int>(std::vector<int>::size());
}


}  // namespace csce240

