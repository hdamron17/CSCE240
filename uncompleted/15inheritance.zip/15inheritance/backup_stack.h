/* Copyright 2018 */
#ifndef _240_LECT_12INHERITANCE_BACKUPSTACK_H_  // NOLINT
#define _240_LECT_12INHERITANCE_BACKUPSTACK_H_  // NOLINT

#include <iostream>
#include <cassert>
#include <vector>

#include "stack.h"

namespace csce240 {

class BackupIntStack : public IntStack  {
public:
  /* create necessary constructors */
  BackupIntStack() : IntStack() {}
  BackupIntStack(const std::vector<int>& vec) : IntStack(vec) {}

  int Pop(); // override to implement backup
  
protected:
  /* add functionality to backup when elems are popped (don't forget copy) */
};

}  // namespace csce240

#endif  // NOLINT
