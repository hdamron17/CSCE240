/* Copyright 2018 */
#ifndef _240_LECT_14INHERITANCE_QUEUE_H_  // NOLINT
#define _240_LECT_14INHERITANCE_QUEUE_H_  // NOLINT

#include <iostream>
#include <cassert>
#include <list>

namespace csce240 {

class IntQueue : public std::list<int>  {
public:
  /* create necessary constructors */
  IntQueue() : std::list<int>() {}
  IntQueue(const std::list<int>& vec) : std::list<int>(vec) {}

  bool Empty() const;

  int Peek() const;
  int Pop();
  void Push(int elem);
};

}  // namespace csce240

#endif  // NOLINT
