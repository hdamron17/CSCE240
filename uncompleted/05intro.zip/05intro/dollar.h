/* Copyright 2018 */

#ifndef LECT_05INTRO_DOLLAR_H_  // NOLINT
#define LECT_05INTRO_DOLLAR_H_  // NOLINT

#endif  // NOLINT
