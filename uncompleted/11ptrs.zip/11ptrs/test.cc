/* Copyright 2018 */
#include "test.h"

bool TestRationalCopy(const String& align) {
  cout << align << "Testing Rational Copy" << endl;
  bool valid = true;

  return valid;
}

/* Improve test speed by creating one Rational and passing it around */
int main(int argc, char* argv[]) {
  cout << "Testing Rational Class" << endl;

  int passed = 0, failed = 0;
  String align = "  ";
  Run(TestRationalCopy(align), passed, failed);
  Run(TestRationalCreation(align), passed, failed);
  Run(TestRationalToRational(align), passed, failed);
  Run(TestRationalAddOp(align), passed, failed);
  Run(TestRationalMulOp(align), passed, failed);
  Run(TestRationalSimplify(align), passed, failed);
  Run(TestRationalToString(align), passed, failed);
  Run(TestRationalToFloat(align), passed, failed);
  Run(TestRationalInsertionOp(align), passed, failed);
  Run(TestRationalExtractionOp(align), passed, failed);

  cout << passed << " of " << (passed + failed) << " passed" << endl;

  return 0;
}

void Run(bool result, int& passed, int& failed) {
  if (result) {
    ++passed;
  }
  else {
    ++failed;
  }
}

bool TestRationalCreation(const String& align) {
  cout << align << "TestRationalCreation" << endl;

  Rational a, b(2, 5), c(1, 0);
  bool valid = true;

  if (a.num() != 0) {
    valid = false;
    cout << align << align << "Expected: 0, Actual: " << a.num() << endl;
  }

  if (a.den() != 1) {
    valid = false;
    cout << align << align << "Expected: 1, Actual: " << a.den() << endl;
  }

  if (b.num() != 2) {
    valid = false;
    cout << align << align << "Expected: 2, Actual: " << b.num() << endl;
  }

  if (b.den() != 5) {
    valid = false;
    cout << align << align << "Expected: 5, Actual: " << b.den() << endl;
  }

  if (c.num() != 0) {
    valid = false;
    cout << align << align << "Expected: 0, Actual: " << c.num() << endl;
  }

  if (c.den() != 0) {
    valid = false;
    cout << align << align << "Expected: 0, Actual: " << c.den() << endl;
  }

  if (!c.is_nan()) {
    valid = false;
    cout << align << align << "Expected: true, Actual: " <<
      (c.is_nan() ? "true" : "false") << endl;
  }

  return valid;
}

bool TestRationalToRational(const String& align) {
  cout << align << "TestRationalToRational" << endl;
  Rational a = Rational::ToRational(0.375), b = Rational::ToRational(NAN);

  bool valid = true;
  if (a.num() != 3) {
    valid = false;
    cout << align << align << "Expected: 3, Actual: " << a.num() << endl;
  }
  if (a.den() != 8) {
    valid = false;
    cout << align << align << "Expected: 8, Actual: " << a.den() << endl;
  }
  if (!b.is_nan()) {
    valid = false;
    cout << align << align << "Expected: true, Actual: " <<
      (b.is_nan() ? "true" : "false") << endl;
  }


  return valid;
}

bool TestRationalSimplify(const String& align) {
  cout << align << "TestRationalSimplify" << endl;
  Rational a(375, 1000);
  a = a.Simplify();

  bool valid = true;
  if (a.num() != 3) {
    valid = false;
    cout << align << align << "Expected: 3, Actual: " << a.num() << endl;
  }
  if (a.den() != 8) {
    valid = false;
    cout << align << align << "Expected: 8, Actual: " << a.den() << endl;
  }


  return valid;
}

bool TestRationalAddOp(const String& align) {
  cout << align << "TestRationalAddOp" << endl;
  Rational a(1, 3), b(3, 9), c, d(1, 0);
  c = a.AddOp(b);

  bool valid = true;
  if (c.num() != 2) {
    valid = false;
    cout << align << align << "Expected: 2, Actual: " << c.num() << endl;
  }

  if (c.den() != 3) {
    valid = false;
    cout << align << align << "Expected: 3, Actual: " << c.den() << endl;
  }

  c = a.AddOp(d);
  if (!c.is_nan()) {
    cout << align << align << "Expected: true, Actual: " <<
        (c.is_nan() ? "true" : "false") << endl;
  }
  return valid;
}

bool TestRationalMulOp(const String& align) {
  cout << align << "TestRationalMulOp" << endl;
  Rational a(3, 7), b(7, 3), c, d(1, 0);
  c = a.MulOp(b);

  bool valid = true;
  if (c.num() != 1) {
    valid = false;
    cout << align << align << "num expected: 1, actual: " << c.num() << endl;
  }
  if (c.den() != 1) {
    valid = false;
    cout << align << align << "den expected: 1, actual: " << c.den() << endl;
  }
  c = c.MulOp(d);
  if (!c.is_nan()) {
    valid = false;
    cout << align << align << "expected: true, acutal: " <<
        (c.is_nan() ? "true" : "false") << endl;
  }

  return valid;
}

bool TestRationalToString(const String& align) {
  cout << align << "TestRationalToString" << endl;
  Rational a(3, 4);

  bool valid = true;
  if (a.ToString() != "3/4") {
    valid = false;
    cout << align << align << "Expected: 3/4, Actual: " << a.ToString() << endl;
  }
  a = Rational(1, 0);
  if (a.ToString() != "nan") {
    valid = false;
    cout << align << align << "Expected: nan, Actual: " << a.ToString() << endl;
  }

  return valid;
}

bool TestRationalToFloat(const String& align) {
  cout << align << "TestRationalToFloat" << endl;
  Rational a(3, 4);

  bool valid = true;
  if (a.ToFloat() != 0.75) {
    valid = false;
    cout << align << align << "Expected: 0.75, Actual: " << a.ToFloat() << endl;
  }
  a = Rational(1, 0);
  if (!isnan(a.ToFloat())) {
    valid = false;
    cout << align << align << "Expected: nan, Actual: " << a.ToFloat() << endl;
  }
  return valid;
}

bool TestRationalInsertionOp(const String& align) {
  cout << align << "TestRationalInsertionOp" << endl;
  StrStream sstr("3 /4");
  Rational a;

  sstr >> a;
  bool valid = true;
  if (a.num() != 3) {
    valid = false;
    cout << align << align << "Expected: 3, Actual: " << a.num() << endl;
  }

  if (a.den() != 4) {
    valid = false;
    cout << align << align << "Expected: 4, Actual: " << a.den() << endl;
  }

  return valid;
}

bool TestRationalExtractionOp(const String& align) {
  cout << align << "TestRationalExtractionOp" << endl;
  StrStream sstr;
  Rational a(4, 7);

  sstr << a;
  bool valid = true;
  if (sstr.str() != "4/7") {
    valid = false;
    cout << align << align << "Expected: 4/7, Actual: " << sstr.str() << endl;
  }

  return valid;
}
