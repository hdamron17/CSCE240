/*
 * Copyright 2018
 */

#include <iostream>
using std::cout;
using std::endl;

#include <cstdlib>
// using rand
// using srand

#include <string>
using std::string;

int main(int argc, char* argv[]) {
  // seed random number gen with a const literal 123
  srand(243);
  // create two const ints for kRows and columns of matrix
  const int kRows = 4;
  const int kCols = 3;

  // create dynamic int matrix
  int **m = new int *[kRows];
  // and assign each element a random [1, 100]
  for (int i = 0; i < kRows; ++i) {
    m[i] = new int[kCols];

    for (int j = 0; j < kCols; ++j)
      // TODO: change to pointer arithmetic
      m[i][j] = rand() % 101 + 1;  // NOLINT
  }

  // print matrix
  for (int i = 0; i < kRows; ++i) {
    for (int j = 0; j < kCols; ++j) {
      // TODO: change to pointer arithmetic
      cout << m[i][j] << '\t';
    }
    cout << endl;
  }

  delete[] m;

  return 0;
}
