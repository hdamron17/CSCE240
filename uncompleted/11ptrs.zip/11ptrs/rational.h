/* Copyright 2018 */

#ifndef _LECT_11PTRS_RATIONAL_H_
#define _LECT_11PTRS_RATIONAL_H_

#include <cctype>
using std::isdigit;
#include <cmath>
// using abs
// using pow
// using NAN
#include <iostream>
using std::istream;
using std::ostream;
#include <string>
using std::to_string;

typedef std::string String;

/* Rational class definition */
class Rational {
public:
  Rational(int num = 0, int den = 1);
  /* TODO: Discuss destructors and implement. Show valgrind */
  // ~Rational(void);

  /* TODO:
   * Discuss deep vs shallow copy and implement the copy constructor
   *  - Show the destructor problem with shallow copies.
   */
  // Rational(const Rational& copy);

  /* TODO: Discuss deep vs shallow copy and implement the assignment operator */
  // const Rational& operator=(const Rational& rhs);


  // approximates Rational value from floating point via
  //   conversion_precision_
  static const Rational ToRational(double val);
  inline static int conversion_precision(void) {
    return Rational::conversion_precision_;
  }
  inline static void conversion_precision(int conversion_precision) {
    if (0 < conversion_precision)
      Rational::conversion_precision_ = conversion_precision;
  }

  // arithmetic methods and operators for Rational class
  //  - all arithmetic returns simplified Rationals
  //  - all arithmetic involving nan Rationals return a nan Rational
  const Rational AddOp(const Rational& rhs) const;
  inline const Rational AddOp(int rhs) const {
    return AddOp(Rational(rhs));
  }
  inline const Rational AddOp(double rhs) const {
    return AddOp(Rational::ToRational(rhs));
  }

  // overloaded operators call the above arithmetic ops
  const Rational operator+(const Rational& rhs) const;
  const Rational operator+(int rhs) const;  // TODO: discuss necessity
  /* TODO: Explain current necessity. Do we need anything else? */
  inline const Rational operator+(double rhs) const {
    return AddOp(Rational::ToRational(rhs));
  }

  const Rational MulOp(const Rational& rhs) const;
  inline const Rational MulOp(int rhs) const {
    return MulOp(Rational(rhs));
  }
  inline const Rational MulOp(double rhs) const {
    return MulOp(Rational::ToRational(rhs));
  }

  // overloaded operators call the above arithmetic ops
  const Rational operator*(const Rational& rhs) const;
  const Rational operator*(int rhs) const;  // TODO: discuss necessity
  /* TODO: explain necessity. Do we need anything else? */
  inline const Rational operator*(double rhs) const {
    return MulOp(Rational::ToRational(rhs));
  }

  // uses Euclid's Algorithm for greatest common factor
  const Rational Simplify() const;

  // ToString and ToFloat methods return nan, appropriately
  const String ToString() const;
  long double ToFloat() const;

  // string output format: "int/int"
  friend istream& operator>>(istream& in, Rational& rhs);
  // string input format "int[:space:]*/[:space:]*int"
  friend ostream& operator<<(ostream& out, const Rational& rhs);

  // getters, no setters; create new Rationals, do not modify existing
  inline int num() const { return num_ ? *num_ : 0;}
  inline int den() const { return den_ ? *den_ : 0;}
  inline bool is_nan() const { return den_ == nullptr; }
private:
  // method to decide approximate equality
  bool FpEq(double a, double b) const;

  static int conversion_precision_;  // precision for double to rational

  // implements Euclid's division-based method
  int CalcGCD(int a, int b) const; // returns GCD of a and b

  int *num_;
  int *den_;
  bool nan_;
};

#endif
