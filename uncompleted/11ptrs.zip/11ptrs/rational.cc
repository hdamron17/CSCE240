#include "rational.h"

int Rational::conversion_precision_ = 6;

Rational::Rational(int num, int den) {
  if (0 != den) {
    num_ = new int(num);
    den_ = new int(den);
  }
  else {
    num_ = den_ = nullptr;
  }
}

const Rational Rational::ToRational(double val) {
  if (isnan(val)) {
    return Rational(0, 0);
  }

  int num = pow(10, Rational::conversion_precision_);

  Rational r(val*num, num);

  return r.Simplify();
}

const Rational Rational::AddOp(const Rational& rhs) const {
  if (is_nan() || rhs.is_nan())
    return Rational(0, 0);

  // den is product of rhs and lhs denominators
  int den = *den_ * *(rhs.den_);
  // numerators are multiplied by others' denominator
  int num_lhs = *num_ * *(rhs.den_);
  int num_rhs = *(rhs.num_) * *den_;

  // sum new numerators and simplify
  return Rational(num_lhs + num_rhs, den).Simplify();
}

const Rational Rational::MulOp(const Rational& rhs) const {
  if (is_nan() || rhs.is_nan())
    return Rational(0, 0);

  return Rational(*num_ * *(rhs.num_), *den_ * *(rhs.den_)).Simplify();
}

const Rational Rational::Simplify() const {
  int gcd = CalcGCD(*num_, *den_);

  return Rational(*num_ / gcd, *den_ / gcd);
}

// Taken from https://en.wikipedia.org/wiki/Euclidean_algorithm 02.13.2018
int Rational::CalcGCD(int a, int b) const {
  int t = 0;
  a = abs(a);
  b = abs(b);

  while (0 != b) {
     t = b;
     b = a % b;
     a = t;
  }

  return a;
}

const String Rational::ToString() const {
  if (is_nan()) {
    return "nan";
  }

  return to_string(*num_) + "/" + to_string(*den_);
}

long double Rational::ToFloat() const {
  if (is_nan()) {
    return NAN;
  }

  return static_cast<long double>(*num_)
      / static_cast<long double>(*den_);
}

istream& operator>>(istream& in, Rational& rhs) {
  int num=0, den=0;
  char bar='\\';

  in >> num >> bar >> den;
  if (den != 0) {
    if (rhs.num_)
      *(rhs.num_) = num;
    else
      rhs.num_ = new int(num);

    if (rhs.den_)
      *(rhs.den_) = den;
    else
      rhs.den_ = new int(den);
  }
  else {
    if (rhs.num_) {
      delete rhs.num_;
      rhs.num_ = nullptr;
    }
    if (rhs.den_) {
      delete rhs.den_;
      rhs.den_ = nullptr;
    }
  }

  return in;
}

ostream& operator<<(ostream& out, const Rational& rhs) {
  out << rhs.ToString();

  return out;
}

/* Tests two floating point numbers for near-equality usually using the
 * relative error, but also with a lower bound on the absolute error for
 * numbers to be considered different.
 *
 * This code is based on Bruce Dawson's "Comparing Floating Point Numbers" at
 * http://www.cygnus-software.com/papers/comparingfloats/comparingfloats.htm.
 */
bool Rational::FpEq(double a, double b) const {
  const double maxAbsoluteError = 0.0001;
  const double maxRelativeError = 0.0001;

  if (fabs(a - b) < maxAbsoluteError) { 
    return true;
  }

  double relativeError;
  if (fabs(b) > fabs(a)) {
   relativeError = fabs((a - b) / b);
  }
  else {
   relativeError = fabs((a - b) / a);
  }

  return (relativeError <= maxRelativeError);
}


