#ifndef _LECT_07INTRO_RATIONAL_H_
#define _LECT_07INTRO_RATIONAL_H_

#include <cctype>
using std::isdigit;
#include <cmath>
// using abs
#include <cstdlib>
// using atoi
#include <iostream>
using std::istream;
using std::ostream;
using std::ws;
#include <sstream>
#include <string>
#include <regex>


typedef std::stringstream StrStream;
typedef std::string String;

/* Rational class definition */
class Rational {
public:
  Rational(int num = 0, int den = 1);

  // create arithmetic ops for Rational instances and ints

  // create overloads for arithmetic ops 

  // create ToString and ToFloat methods

  // create getters for members

  // create method which creates, simplifies, and returns a new instance 
private:

  int num_;
  int den_;
  bool nan_;
};
#endif
