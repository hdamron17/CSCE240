/* Copyright 2018 */
#include "test.h"


int main(int argc, char* argv[]) {
  cout << "Testing Rational Class" << endl;

  return 0;
}

