/* Copyright 2018 */

#ifndef LECT_07INTRO_TEST_H_  // NOLINT
#define LECT_07INTRO_TEST_H_  // NOLINT

#include <cassert>
// using assert
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <string>
using std::string;

#include "rational.h"


#endif  // NOLINT
