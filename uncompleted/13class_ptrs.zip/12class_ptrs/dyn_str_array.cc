#include "dyn_str_array.h"

DynStrArray::DynStrArray(int size) {
  if (0 < size) {
    size_ = size;
    array_ = new String[size_];
  }
  else {
    array_ = nullptr;
    size_ = 0;
  }
  last_ = -1;
}

DynStrArray::DynStrArray(const DynStrArray& copy) {
  if (copy.array_) {
    array_ = new String[copy.size_];
    for (int i = 0; i < copy.size_; ++i) {
      *(array_ + i) = *(copy.array_ + i);
    }
  }
  size_ = copy.size_;
  last_ = copy.last_;
}


DynStrArray::~DynStrArray() {
  if (array_) {
    delete[] array_;
  }
}

const String DynStrArray::Get(int index) const {
  assert(-1 < index && index <= last_);
  return *(array_ + index);
}

void DynStrArray::Set(int index, const String& val) {
  assert(-1 < index && index <= last_);
  array_[index] = val;
}

int DynStrArray::Size() {
  return last_ + 1;
}

DynStrArray& DynStrArray::operator=(const DynStrArray& rhs) {
  if (this == &rhs) {
    return *this;
  }

  if (array_) {
    delete[] array_;
    array_ = nullptr;
  }

  if (rhs.array_) {
    array_ = new String[rhs.size_];
    for (int i = 0; i < rhs.size_; ++i) {
      *(array_ + i) = *(rhs.array_ + i);
    }
  }
  size_ = rhs.size_;
  last_ = rhs.last_;

  return *this;
}

