/* Copyright 2018 */

#ifndef _LECT_12CLASS_PTRS_DYN_STR_ARRAY_H_  // NOLINT
#define _LECT_12CLASS_PTRS_DYN_STR_ARRAY_H_  // NOLINT

#include <cassert>
#include <cmath>
// using round
#include <string>
typedef std::string String;
#include <iostream>
using std::endl;
using std::cout; 

/* DynStrArray class definition */
class DynStrArray {
public:
  /* TODO: Implement default constructor and constructor setting initial size
   * from signed integer
   */
   DynStrArray(int size=0);
   DynStrArray(const DynStrArray& copy);
   ~DynStrArray();

  /* TODO: Implement getter and setter for elements */
  const String Get(int index) const;
  void Set(int index, const String& val);

  /* TODO: Implement method to determine number of elements as a signed integer
   * called Size
   */
  int Size();

  /* TODO: Implement Add method to add string at index, a signed integer method
   * parameter
   */

  /* TODO: Implement Remove method to remove string at index, a signed integer
   * method parameter
   */

  /* TODO: Implement a ToString method which accepts a String delimiter with a
   * default value of ", "
   */

  /* TODO:
   * Discuss deep vs shallow copy and implement the copy constructor
   *  - Show the destructor problem with shallow copies.
   */

  /* TODO: Discuss deep vs shallow copy and implement the assignment operator */
  DynStrArray& operator=(const DynStrArray& rhs);
private:
  String *array_;
  int size_;
  int last_;
};

#endif
