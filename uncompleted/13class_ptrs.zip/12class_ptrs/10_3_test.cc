/* Copyright 2018 */
#include "10_3_test.h"  // NOLINT

bool TestDynStrArrayCreate() {
  DynStrArray str_arr(3), str_brr(-1);
  DynStrArray str_crr = str_brr;


  return false;
}

bool TestDynStrArraySize() {
  DynStrArray str_arr, str_brr(100);

  return (str_arr.Size() == 0 && str_brr.Size() == 0);
}

bool TestDynStrArrayGetSet() {
  DynStrArray str_arr, str_brr(100);

  return false;
}

/* Improve test speed by creating one Rational and passing it around */
int main(int argc, char* argv[]) {
  srand(time(nullptr));  // pass nullptr to time to get return value

  cout << "Testing DynStrArray Class" << endl;

  int passed = 0, failed = 0;
  String align = "  ";

  Run(TestDynStrArrayCreate(), &passed, &failed);
  Run(TestDynStrArraySize(), &passed, &failed);

  cout << passed << " of " << (passed + failed) << " passed" << endl;

  return 0;
}

const String RandString(int size) {
  String r_string;

  for (int i = 0; i < size; ++i)
    r_string += static_cast<char>('A' + rand() % 26);  // NOLINT

  return r_string;
}

void Run(bool result, int* passed, int* failed) {
  if (result)
    ++(*passed);

  else
    ++(*failed);
}

