/* Copyright 2018 */

#include "14_1_test.h"  // NOLINT

/* Improve test speed by creating one Rational and passing it around */
int main(int argc, char* argv[]) {
  srand(time(nullptr));  // pass nullptr to time to get return value

  cout << "Testing DynStrArray Class" << endl;

  int passed = 0, failed = 0;
  String align = "  ";


  cout << passed << " of " << (passed + failed) << " passed" << endl;

  return 0;
}

const String RandString(int size) {
  String r_string;

  for (int i = 0; i < size; ++i)
    r_string += static_cast<char>('A' + rand() % 26);  // NOLINT

  return r_string;
}

void Run(bool result, int* passed, int* failed) {
  if (result)
    ++(*passed);

  else
    ++(*failed);
}

