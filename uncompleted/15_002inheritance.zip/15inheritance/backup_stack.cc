/* Copyright 2018 */

#include "backup_stack.h"  // NOLINT

namespace csce240 {

int BackupIntStack::Pop() {
  assert(0 < size());

  int top = IntStack::Pop();
  undo_stack_.Push(top);
  return top;
}

bool BackupIntStack::Undo() {
  if (undo_stack_.Empty())
    return false;

  IntStack::Push(undo_stack_.Pop());
  return true;
}

}  // namespace csce240

