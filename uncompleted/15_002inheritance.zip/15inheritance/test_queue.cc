/* Copyright 2018 */

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <string>
using std::stoi;
#include <list>
typedef std::list<int> List;


#include "queue.h"
using csce240::IntQueue;

void EmptyQueue(IntQueue& queue) {
  while (!queue.Empty()) {
    cout << "queue.Pop(): " << queue.Pop() << endl;
  }
}

void PrintList(const List& list) {
  for (List::const_iterator it = list.begin(); it != list.end(); ++it) {
    cout << "it : " << *it << endl;
  }
}

void FillList(unsigned int size, List* list) {
  for (unsigned int i = 0; i < size; ++i) {
    list->push_back(i);
  }
}

void FillQueue(int size, IntQueue* queue) {
  for (int i = 0; i < size; ++i) {
    queue->Push(i);
  }
}

int main(int argc, char* argv[]) {
  IntQueue queue;
  FillQueue(5, &queue);
  //PrintList(queue);
  EmptyQueue(queue);

  return 0;
}
