/* Copyright 2018 */

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <string>
using std::stoi;
#include <vector>
using std::vector;


#include "stack.h"
using csce240::IntStack;

bool TestVecAtBounds(const vector<int>& vec) {
  vec.at(-1);
  return false;
}

bool TestIntStackAtBounds(const IntStack& stack) {
  stack.at(-1);
  return false;
}

void EmptyStack(IntStack& stack) {
  while (!stack.Empty()) {
    cout << "stack.Pop(): " << stack.Pop() << endl;
  }
}

void PrintVector(const vector<int>& vec) {
  for (unsigned int i = 0; i < vec.size(); ++i) {
    cout << "vec[" << i << "]: " << vec.at(i) << endl;
  }
}

void FillVector(unsigned int size, vector<int>* vec) {
  for (unsigned int i = 0; i < size; ++i) {
    vec->push_back(i);
  }
}

void FillStack(int size, IntStack* stack) {
  for (int i = 0; i < size; ++i) {
    stack->Push(i);
  }
}

int main(int argc, char* argv[]) {
  vector<int> vec;
  FillVector(5, &vec);
  IntStack stack(vec);
  EmptyStack(stack);

  if (1 < argc) {
    switch(stoi(argv[1])) {
    case 1:
      if (!TestIntStackAtBounds(stack))
        cout << "TestStackAtBounds failed!!" << endl;
      break;
    }
  }
  return 0;
}
