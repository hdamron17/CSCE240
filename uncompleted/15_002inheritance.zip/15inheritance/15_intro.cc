#include<iostream>
using std::cout;
using std::endl;
 
class Base {
 public:
  Base(double a = 1.0) : a_(a) {}

  void Print() const {
    cout << "value: " << Value() << endl;
  }

 protected:
  virtual double Value() const {
    return a_;
  }
  double a_;
};
 
class Derived : public Base {
 protected:
  double Value() const override {
    return 1.75*a_;
  }
};
 
int main(int argc, char* argv[]) {
  Base b;
  Derived d1;
  b = d1;  // slicing problem
  Base *b_ptr = &d1;

  // base class function, bound at compile time
  cout << "Base class method:\n\t";
  b.Print();
   
  //virtual function, bound at runtime
  cout << "Virtual derived method:\n\t";
  b_ptr->Print();

  Derived *d2 = dynamic_cast<Derived *>(b_ptr);
  // base class function, bound at compile time
  cout << "Derived method:\n\t";
  d2->Print();

  return 0;
}
