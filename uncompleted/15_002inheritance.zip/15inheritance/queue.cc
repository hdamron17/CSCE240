/* Copyright 2018 */

#include "queue.h"  // NOLINT

namespace csce240 {

bool IntQueue::Empty() const {
  return 0 == size();
}

int IntQueue::Peek() const {
  assert(0 < size());

  return back();
}

int IntQueue::Pop() {
  assert(0 < size());

  int tmp = back();  // save a copy of "top" of queue
  pop_back();  // remove "top" of queue
  return tmp;
}


void IntQueue::Push(int elem) {
  push_front(elem);
}

}  // namespace csce240

